<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Home')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

    <style>
        #navbarSupportedContent{
            display: flex;
            -webkit-box-align: center;
            align-items: center;
        }
        .btn-group-lg>.btn, .btn-lg {
            padding: .5rem 1rem;
            font-size: 1.25rem;
            line-height: 1.5;
            border-radius: .3rem;
            background-color: #353b44;
            border-style: none;
        }
        .navbar-collapse{
            display: flex;
            -webkit-box-align: center;
            align-items: center;

        }
        #penn{
            display: flex;
            -webkit-box-align: center;
            align-items: center;
            width: 250px;
            position: absolute;
            left: 1050px;
            top: 120px;
        }
        body {
            font-family: -apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,sans-serif;
            font-size: 1rem;
            line-height: 1.5;
            color: #373a3c;
        }
        ._1hrylyvr {
            position: relative;
            min-height: 1px;
            width: 100%;
            padding-left: 12px;
            padding-right: 12px;
        }
        .rc-AtAGlance ul  .feature-item{
            list-style: none;
            font-size: 16px;
            line-height: 21px;
            font-family: OpenSans,Arial,sans-serif;
            line-height: 1.5;
            display: -ms-flexbox;
            display: flex;
            margin-top: 30px;
            padding: 0;
        }
        .p-b--24, .rc-DeadlineInfo .styled h3:first-child {
            padding-bottom: 24px!important;
        }
        li {
            display: list-item;
            text-align: -webkit-match-parent;

        }
        ul {
            font-size: 1em;
            outline: 0;
        }
        .feature-title{
            margin-left: 10px;
        }

        #navbarSupportedContent{
            display: flex;
            -webkit-box-align: center;
            align-items: center;
        }

        .dropbtn {
            color: white;
            padding: 16px;
            font-size: 16px;
            border: none;
            cursor: pointer;
        }

        /*.dropbtn:hover, .dropbtn:focus {*/
        /*    background-color: #3e8e41;*/
        /*}*/

        .dropdown {
            float: right;
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f1f1f1;
            min-width: 160px;
            overflow: auto;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            right: 0;
            z-index: 1;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown a:hover {background-color: #ddd;}

        .show {display: block;}
    </style>

</head>
<body style="background-color: #ffff52">
<div id="app">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">

        <nav class="navbar navbar-dark bg-light">
            <a class="navbar-brand" href="#" style="color: #303a44">
                <svg class="bi bi-intersect" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg" style="color:#a2e9e9;">
                    <path fill-rule="evenodd" d="M12 4v6.5a1.5 1.5 0 01-1.5 1.5H4V5.5A1.5 1.5 0 015.5 4H12z" clip-rule="evenodd"/>
                    <path fill-rule="evenodd" d="M14.5 5h-9a.5.5 0 00-.5.5v9a.5.5 0 00.5.5h9a.5.5 0 00.5-.5v-9a.5.5 0 00-.5-.5zm-9-1A1.5 1.5 0 004 5.5v9A1.5 1.5 0 005.5 16h9a1.5 1.5 0 001.5-1.5v-9A1.5 1.5 0 0014.5 4h-9z" clip-rule="evenodd"/>
                    <path fill-rule="evenodd" d="M10.5 1h-9a.5.5 0 00-.5.5v9a.5.5 0 00.5.5h9a.5.5 0 00.5-.5v-9a.5.5 0 00-.5-.5zm-9-1A1.5 1.5 0 000 1.5v9A1.5 1.5 0 001.5 12h9a1.5 1.5 0 001.5-1.5v-9A1.5 1.5 0 0010.5 0h-9z" clip-rule="evenodd"/>
                </svg>
                A.B.P.
            </a>
        </nav>

        <div class="dropdown">
            <button onclick="myFunction()" class="dropbtn"> <span class="navbar-toggler-icon"></span></button>
            <div id="myDropdown" class="dropdown-content">
                <p ><a class="btn btn-secondary" href="<?php echo e(url('/pyth')); ?>" role="button"  style="background-color: #a2e9e9; border-color:#a2e9e9; color:#353b44 ; ">View details Python >></a></p>
                <p><a class="btn btn-secondary" href="<?php echo e(url('/data')); ?>" role="button"  style="background-color: #a2e9e9; border-color:#a2e9e9; color:#353b44 ; ">View details Data >></a></p>
                <p><a class="btn btn-secondary" href="<?php echo e(url('/home')); ?>" role="button"  style="background-color: #a2e9e9; border-color:#a2e9e9; color:#353b44 ; ">Return to Calendar >></a></p>
            </div>
        </div>


        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <?php echo e(config('app.Home', 'Home')); ?>

                    </a>
                </li>


            </ul>

            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto">
                <!-- Authentication Links -->
                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                    </li>
                    <?php if(Route::has('register')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                    
                    <a id="navbarDropdown" class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                    </a>

                    
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                        <?php echo e(__('Logout')); ?>

                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                    
                    
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>
    <div class="jumbotron" style="background-color: #ffff52;">
        <font color="#daf7ff"><div class="container">
                <h1 class="display-3" style="color: #303a44; font-family: Appetite;">Master of Computer and <br>Information Technology</h1>
                <p style="color: #303a44; font-size: 20px; font-weight: bold;">University of Pennsylvania</p>
                <img id="penn" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c7/Penn_Quakers_logo.svg/493px-Penn_Quakers_logo.svg.png">
            </div>
        </font>
    </div>

    <div class="container justify-content-center ">
        <!-- Example row of columns -->
        <div class="row featurette justify-content-center">
            <div class="col-md-7">
                <h2 class="featurette-heading">The only online Ivy League master’s degree in Computer Science designed for students without a Computer Science background.</h2>
                <p class="lead">The online Master of Computer and Information Technology degree (MCIT Online) is an online masters degree in Computer Science tailored for non-Computer Science majors. Offered by the University of Pennsylvania, this new program brings the long-running, established on-campus MCIT degree online. The MCIT Online program empowers students without computer science backgrounds to succeed in computing and technology fields. MCIT Online students come from diverse academic backgrounds ranging from business and history to chemistry and medicine.<br></p>
                <br>

                Computer science might not be in your past, but it will be in your future. Technology has an immense impact on our lives, and is creating fields and positions that didn’t exist five years ago. Equipped with a competitive computer science degree, MCIT Online graduates will be uniquely positioned to fill roles in finance, healthcare, education, and government, as well as in the core software development industry. Exposure to real-world projects throughout the program will prepare students to utilize skills that positively impact society.<br>
            </div>
            <div class="col-md-5">
                <div class="_1hrylyvr">
                    <div class="rc-InfoSideabar rc-Section m-l--24" >
                        <div class="rc-AtAGlance" >
                            <ul>
                                <li class="feature-item p-b--24">
                                    <svg class="bi bi-tag" width="1.5em" height="1.5em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" d="M.5 2A1.5 1.5 0 012 .5h4.586a1.5 1.5 0 011.06.44l7 7a1.5 1.5 0 010 2.12l-4.585 4.586a1.5 1.5 0 01-2.122 0l-7-7A1.5 1.5 0 01.5 6.586V2zM2 1.5a.5.5 0 00-.5.5v4.586a.5.5 0 00.146.353l7 7a.5.5 0 00.708 0l4.585-4.585a.5.5 0 000-.708l-7-7a.5.5 0 00-.353-.146H2z" clip-rule="evenodd"/>
                                        <path fill-rule="evenodd" d="M2.5 4.5a2 2 0 114 0 2 2 0 01-4 0zm2-1a1 1 0 100 2 1 1 0 000-2z" clip-rule="evenodd"/>
                                    </svg>
                                    <div class="feature-description">
                                        <div class="feature-title">
                                            <strong aria-label="$25,000 (tuition) + $1,300 (online services fees)">
                                                $25,000 (tuition) + $1,300 (online services fees)
                                            </strong>
                                        </div>
                                    </div>
                                </li>
                                <li class="feature-item p-b--24">
                                    <div class="feature-visual">
                                        <svg class="bi bi-clock" width="1.5em" height="1.5em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" d="M8 15A7 7 0 108 1a7 7 0 000 14zm8-7A8 8 0 110 8a8 8 0 0116 0z" clip-rule="evenodd"/>
                                            <path fill-rule="evenodd" d="M7.5 3a.5.5 0 01.5.5v5.21l3.248 1.856a.5.5 0 01-.496.868l-3.5-2A.5.5 0 017 9V3.5a.5.5 0 01.5-.5z" clip-rule="evenodd"/>
                                        </svg>
                                    </div>
                                    <div class="feature-description">
                                        <div class="feature-title">
                                            <strong aria-label="16-40 months">
                                                16-40 months
                                            </strong>
                                        </div>
                                    </div>
                                </li>
                                <li class="feature-item p-b--24">
                                    <div class="feature-visual">
                                        <svg class="bi bi-bar-chart" width="1.5em" height="1.5em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" d="M4 11H2v3h2v-3zm5-4H7v7h2V7zm5-5h-2v12h2V2zm-2-1a1 1 0 00-1 1v12a1 1 0 001 1h2a1 1 0 001-1V2a1 1 0 00-1-1h-2zM6 7a1 1 0 011-1h2a1 1 0 011 1v7a1 1 0 01-1 1H7a1 1 0 01-1-1V7zm-5 4a1 1 0 011-1h2a1 1 0 011 1v3a1 1 0 01-1 1H2a1 1 0 01-1-1v-3z" clip-rule="evenodd"/>
                                        </svg>
                                    </div>
                                    <div class="feature-description">
                                        <div class="feature-title">
                                            <strong aria-label="10 courses">
                                                10 courses
                                            </strong>
                                        </div>
                                    </div>
                                </li>
                                <li class="feature-item">
                                    <div class="feature-visual">
                                        <svg class="bi bi-map" width="1.5em" height="1.5em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" d="M15.817.613A.5.5 0 0116 1v13a.5.5 0 01-.402.49l-5 1a.502.502 0 01-.196 0L5.5 14.51l-4.902.98A.5.5 0 010 15V2a.5.5 0 01.402-.49l5-1a.5.5 0 01.196 0l4.902.98 4.902-.98a.5.5 0 01.415.103zM10 2.41l-4-.8v11.98l4 .8V2.41zm1 11.98l4-.8V1.61l-4 .8v11.98zm-6-.8V1.61l-4 .8v11.98l4-.8z" clip-rule="evenodd"/>
                                        </svg>
                                    </div>
                                    <div class="feature-description">
                                        <div class="feature-title">
                                            <strong aria-label="Completely online">
                                                Completely online
                                            </strong>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                            <div class="rc-DeadlineInfo" style=" border: 1px solid black; margin-left:35px; margin-top: 100px; font-size: 16px; padding: 24px!important;">
                                <div class="rc-Markdown styled finalDeadlineInfo">
                                    <p>
                                        Applications for the Fall 2020 cohort are now open.
                                    </p>
                                    <p>
                                        The early application deadline is March 1st.
                                    </p>
                                    <p>
                                        The final application deadline is May 1st.
                                    </p>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </div> <!-- /container -->

</div>
<footer class="container" >
    <p> <a class="navbar-brand" href="https://www.instagram.com/vmiinv" style="color: darkgrey">
            <svg class="bi bi-at" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" d="M13.106 7.222c0-2.967-2.249-5.032-5.482-5.032-3.35 0-5.646 2.318-5.646 5.702 0 3.493 2.235 5.708 5.762 5.708.862 0 1.689-.123 2.304-.335v-.862c-.43.199-1.354.328-2.29.328-2.926 0-4.813-1.88-4.813-4.798 0-2.844 1.921-4.881 4.594-4.881 2.735 0 4.608 1.688 4.608 4.156 0 1.682-.554 2.769-1.416 2.769-.492 0-.772-.28-.772-.76V5.206H8.923v.834h-.11c-.266-.595-.881-.964-1.6-.964-1.4 0-2.378 1.162-2.378 2.823 0 1.737.957 2.906 2.379 2.906.8 0 1.415-.39 1.709-1.087h.11c.081.67.703 1.148 1.503 1.148 1.572 0 2.57-1.415 2.57-3.643zm-7.177.704c0-1.197.54-1.907 1.456-1.907.93 0 1.524.738 1.524 1.907S8.308 9.84 7.371 9.84c-.895 0-1.442-.725-1.442-1.914z" clip-rule="evenodd"/>
            </svg>
            vmiinv
        </a>

        <a class="navbar-brand" href="https://www.instagram.com/beksultankarl" style="color: darkgrey"  >
            <svg class="bi bi-at" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" d="M13.106 7.222c0-2.967-2.249-5.032-5.482-5.032-3.35 0-5.646 2.318-5.646 5.702 0 3.493 2.235 5.708 5.762 5.708.862 0 1.689-.123 2.304-.335v-.862c-.43.199-1.354.328-2.29.328-2.926 0-4.813-1.88-4.813-4.798 0-2.844 1.921-4.881 4.594-4.881 2.735 0 4.608 1.688 4.608 4.156 0 1.682-.554 2.769-1.416 2.769-.492 0-.772-.28-.772-.76V5.206H8.923v.834h-.11c-.266-.595-.881-.964-1.6-.964-1.4 0-2.378 1.162-2.378 2.823 0 1.737.957 2.906 2.379 2.906.8 0 1.415-.39 1.709-1.087h.11c.081.67.703 1.148 1.503 1.148 1.572 0 2.57-1.415 2.57-3.643zm-7.177.704c0-1.197.54-1.907 1.456-1.907.93 0 1.524.738 1.524 1.907S8.308 9.84 7.371 9.84c-.895 0-1.442-.725-1.442-1.914z" clip-rule="evenodd"/>
            </svg>
            beksultankral
        </a>
    </p>
    <p>
        <svg class="bi bi-chat-square-dots" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" d="M14 1H2a1 1 0 00-1 1v8a1 1 0 001 1h2.5a2 2 0 011.6.8L8 14.333 9.9 11.8a2 2 0 011.6-.8H14a1 1 0 001-1V2a1 1 0 00-1-1zM2 0a2 2 0 00-2 2v8a2 2 0 002 2h2.5a1 1 0 01.8.4l1.9 2.533a1 1 0 001.6 0l1.9-2.533a1 1 0 01.8-.4H14a2 2 0 002-2V2a2 2 0 00-2-2H2z" clip-rule="evenodd"/>
            <path d="M5 6a1 1 0 11-2 0 1 1 0 012 0zm4 0a1 1 0 11-2 0 1 1 0 012 0zm4 0a1 1 0 11-2 0 1 1 0 012 0z"/>
        </svg>
        <a href="https://api.whatsapp.com/send?phone=87472485570&text=Hello!" style="color:darkgrey">Whatsapp</a>

    </p>
    <p>© 2020y. <a class="float-right"href="#" style="color:#00d8d8">Back to top</a></p>

</footer>
<script>
    /* When the user clicks on the button,
    toggle between hiding and showing the dropdown content */
    function myFunction() {
        document.getElementById("myDropdown").classList.toggle("show");
    }

    // Close the dropdown if the user clicks outside of it
    window.onclick = function(event) {
        if (!event.target.matches('.dropbtn')) {
            var dropdowns = document.getElementsByClassName("dropdown-content");
            var i;
            for (i = 0; i < dropdowns.length; i++) {
                var openDropdown = dropdowns[i];
                if (openDropdown.classList.contains('show')) {
                    openDropdown.classList.remove('show');
                }
            }
        }
    }
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\project\resources\views/ml.blade.php ENDPATH**/ ?>