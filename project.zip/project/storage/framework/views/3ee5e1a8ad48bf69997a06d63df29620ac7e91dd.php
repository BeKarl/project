<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Home')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

    <style>
        #navbarSupportedContent{
            display: flex;
            -webkit-box-align: center;
            align-items: center;
        }
        .btn-group-lg>.btn, .btn-lg {
            padding: .5rem 1rem;
            font-size: 1.25rem;
            line-height: 1.5;
            border-radius: .3rem;
            background-color: #353b44;
            border-style: none;
        }
        .navbar-collapse{
            display: flex;
            -webkit-box-align: center;
            align-items: center;

        }
        #penn{
            display: flex;
            -webkit-box-align: center;
            align-items: center;
            width: 250px;
            position: absolute;
            left: 1050px;
            top: 120px;
        }
        body {
            font-family: -apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,sans-serif;
            font-size: 1rem;
            line-height: 1.5;
            color: #373a3c;
        }
        ._1hrylyvr {
            position: relative;
            min-height: 1px;
            width: 100%;
            padding-left: 12px;
            padding-right: 12px;
        }
        .rc-AtAGlance ul  .feature-item{
            list-style: none;
            font-size: 15px;
            line-height: 21px;
            font-family: OpenSans,Arial,sans-serif;
            line-height: 1.5;
            display: -ms-flexbox;
            display: flex;
            margin-top: 10px;
            padding: 0;
        }
        .p-b--24, .rc-DeadlineInfo .styled h3:first-child {
            padding-bottom: 24px!important;
        }
        li {
            display: list-item;
            text-align: -webkit-match-parent;

        }
        ul {
            font-size: 1em;
            outline: 0;
        }
        .feature-title{
            margin-left: 10px;
        }
        #navbarSupportedContent{
            display: flex;
            -webkit-box-align: center;
            align-items: center;
        }

        .dropbtn {
            color: white;
            padding: 16px;
            font-size: 16px;
            border: none;
            cursor: pointer;
        }

        /*.dropbtn:hover, .dropbtn:focus {*/
        /*    background-color: #3e8e41;*/
        /*}*/

        .dropdown {
            float: right;
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f1f1f1;
            min-width: 160px;
            overflow: auto;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            right: 0;
            z-index: 1;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown a:hover {background-color: #ddd;}

        .show {display: block;}



    </style>

</head>
<body style="background-color: #cef6e9">
<div id="app">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">

        <nav class="navbar navbar-dark bg-light">
            <a class="navbar-brand" href="#" style="color: #303a44">
                <svg class="bi bi-intersect" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg" style="color:#a2e9e9;">
                    <path fill-rule="evenodd" d="M12 4v6.5a1.5 1.5 0 01-1.5 1.5H4V5.5A1.5 1.5 0 015.5 4H12z" clip-rule="evenodd"/>
                    <path fill-rule="evenodd" d="M14.5 5h-9a.5.5 0 00-.5.5v9a.5.5 0 00.5.5h9a.5.5 0 00.5-.5v-9a.5.5 0 00-.5-.5zm-9-1A1.5 1.5 0 004 5.5v9A1.5 1.5 0 005.5 16h9a1.5 1.5 0 001.5-1.5v-9A1.5 1.5 0 0014.5 4h-9z" clip-rule="evenodd"/>
                    <path fill-rule="evenodd" d="M10.5 1h-9a.5.5 0 00-.5.5v9a.5.5 0 00.5.5h9a.5.5 0 00.5-.5v-9a.5.5 0 00-.5-.5zm-9-1A1.5 1.5 0 000 1.5v9A1.5 1.5 0 001.5 12h9a1.5 1.5 0 001.5-1.5v-9A1.5 1.5 0 0010.5 0h-9z" clip-rule="evenodd"/>
                </svg>
                A.B.P.
            </a>
        </nav>

        <div class="dropdown">
            <button onclick="myFunction()" class="dropbtn"> <span class="navbar-toggler-icon"></span></button>
            <div id="myDropdown" class="dropdown-content">
                <p><a class="btn btn-secondary" href="<?php echo e(url('/ml')); ?>" role="button"  style="background-color: #a2e9e9; border-color:#a2e9e9; color:#353b44 ; ">View details ML >></a></p>
                <p ><a class="btn btn-secondary" href="<?php echo e(url('/pyth')); ?>" role="button"  style="background-color: #a2e9e9; border-color:#a2e9e9; color:#353b44 ; ">View details Python >></a></p>
                <p><a class="btn btn-secondary" href="<?php echo e(url('/home')); ?>" role="button"  style="background-color: #a2e9e9; border-color:#a2e9e9; color:#353b44 ; ">Return to Calendar >></a></p>
            </div>
        </div>


        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <?php echo e(config('app.Home', 'Home')); ?>

                    </a>
                </li>


            </ul>

            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto">
                <!-- Authentication Links -->
                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                    </li>
                    <?php if(Route::has('register')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                    
                    <a id="navbarDropdown" class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                    </a>

                    
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                        <?php echo e(__('Logout')); ?>

                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                    
                    
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>
    <div class="jumbotron" style="background-color: #cef6e9;">
        <font color="#daf7ff">
            <div class="container">
                <h1 class="display-3" style="color: #303a44; font-family: Appetite;">Introduction to Data  <br>Science in Python</h1>
                <p style="color: #303a44; font-size: 20px; font-weight: bold;">Christopher Brooks</p>
                <img id="penn" src="https://images-na.ssl-images-amazon.com/images/I/519c1FWTzNL._AC_SL1000_.jpg">
            </div>
        </font>
    </div>

    <div class="container justify-content-center ">
        <!-- Example row of columns -->
        <div class="row featurette justify-content-center">
            <div class="col-md-7">
                <h2 class="featurette-heading"> About this course</h2>
                <p class="lead">This course will introduce the learner to the basics of the python programming environment, including fundamental python programming techniques such as lambdas, reading and manipulating csv files, and the numpy library. The course will introduce data manipulation and cleaning techniques using the popular python pandas data science library and introduce the abstraction of the Series and DataFrame as the central data structures for data analysis, along with tutorials on how to use functions such as groupby, merge, and pivot tables effectively. By the end of this course, students will be able to take tabular data, clean it, manipulate it, and run basic inferential statistical analyses.
                    <br>
                    This course should be taken before any of the other Applied Data Science with Python courses: Applied Plotting, Charting & Data Representation in Python, Applied Machine Learning in Python, Applied Text Mining in Python, Applied Social Network Analysis in Python..</p>
            </div>
            <div class="col-md-5">
                <div class="_1hrylyvr">
                    <div class="rc-InfoSideabar rc-Section m-l--24" >
                        <div class="rc-AtAGlance" >
                            <ul>
                                <li class="feature-item p-b--24">
                                    <div class="_1dfpihp m-x-1s m-b-1s m-r-1" data-reactid="584">
                                        <svg aria-hidden="true" class="_ufjrdd" style="fill:black;height:20px;width:20px;" viewBox="0 0 48 48" role="img" aria-labelledby="100%онлайн40fa1471-885c-440c-b5b5-fa9c1d9489ab 100%онлайн40fa1471-885c-440c-b5b5-fa9c1d9489abDesc" xmlns="http://www.w3.org/2000/svg" data-reactid="585">
                                            <title id="100%онлайн40fa1471-885c-440c-b5b5-fa9c1d9489ab" data-reactid="586">
                                                100% онлайн
                                            </title>
                                            <path d="M29.144,2.6074 C30.868,4.5654 32.31,7.5324 33.322,11.1824 C36.407,10.4934 38.17,9.4914 39.698,8.6014 C36.855,5.7034 33.218,3.5864 29.144,2.6074 L29.144,2.6074 Z M8.239,8.6654 C9.691,9.5474 11.656,10.5824 15.059,11.2674 C16.093,7.5044 17.581,4.4624 19.364,2.4914 C15.054,3.4194 11.208,5.6144 8.239,8.6654 L8.239,8.6654 Z M17.026,11.5984 C18.939,11.8624 21.228,12.0234 24,12.0234 C27.009,12.0234 29.408,11.8414 31.364,11.5454 C29.704,5.6564 26.962,2.1054 24.321,2.0024 C24.263,2.0014 24.206,2.0014 24.148,2.0004 C21.478,2.0484 18.698,5.6304 17.026,11.5984 L17.026,11.5984 Z M2.022,23.0004 L13.482,23.0004 C13.543,19.4734 13.93,16.1644 14.579,13.2154 C10.664,12.4204 8.499,11.1834 6.891,10.1844 C4.03,13.7214 2.24,18.1604 2.022,23.0004 L2.022,23.0004 Z M15.482,23.0004 L32.923,23.0004 C32.861,19.4734 32.472,16.2744 31.855,13.4984 C29.767,13.8234 27.209,14.0234 24,14.0234 C21.035,14.0234 18.585,13.8444 16.538,13.5524 C15.928,16.3154 15.543,19.4964 15.482,23.0004 L15.482,23.0004 Z M34.923,23.0004 L45.977,23.0004 C45.758,18.1314 43.95,13.6704 41.06,10.1234 C40.978,10.1704 40.896,10.2184 40.813,10.2664 C39.129,11.2484 37.204,12.3704 33.808,13.1304 C34.467,16.1004 34.861,19.4394 34.923,23.0004 L34.923,23.0004 Z M23.915,33.4534 C27.147,33.4534 29.78,33.6774 31.956,34.0364 C32.515,31.3704 32.864,28.3324 32.923,25.0004 L15.482,25.0004 C15.54,28.2944 15.883,31.3024 16.431,33.9474 C18.471,33.6414 20.922,33.4534 23.915,33.4534 L23.915,33.4534 Z M2.022,25.0004 C2.233,29.6894 3.92,34.0034 6.627,37.4834 C6.703,37.4394 6.78,37.3944 6.858,37.3494 C8.586,36.3414 10.707,35.1064 14.475,34.3004 C13.889,31.4754 13.54,28.3354 13.482,25.0004 L2.022,25.0004 Z M33.905,34.4184 C37.597,35.2674 39.727,36.5214 41.338,37.5274 C44.065,34.0394 45.766,29.7094 45.977,25.0004 L34.923,25.0004 C34.864,28.3824 34.506,31.5634 33.905,34.4184 L33.905,34.4184 Z M33.443,36.3704 C32.426,40.2264 30.938,43.3554 29.144,45.3924 C33.373,44.3754 37.132,42.1334 40.02,39.0634 C38.571,38.1704 36.649,37.1104 33.443,36.3704 L33.443,36.3704 Z M7.947,39.0284 C10.955,42.2394 14.911,44.5494 19.364,45.5084 C17.504,43.4524 15.965,40.2294 14.927,36.2404 C11.531,36.9614 9.609,38.0614 7.947,39.0284 L7.947,39.0284 Z M16.888,35.8944 C18.541,42.1664 21.404,45.9494 24.148,45.9994 C24.206,45.9994 24.263,45.9984 24.321,45.9974 C27.031,45.8924 29.847,42.1574 31.492,35.9904 C29.446,35.6594 26.966,35.4534 23.915,35.4534 C21.091,35.4534 18.793,35.6194 16.888,35.8944 L16.888,35.8944 Z M24.203,48.0004 L24,48.0004 C10.767,48.0004 0,37.2334 0,24.0004 C0,10.7664 10.767,0.0004 24,0.0004 L24.203,0.0004 C24.26,0.0004 24.317,0.0014 24.375,0.0034 C37.436,0.2044 48,10.8914 48,24.0004 C48,37.1084 37.436,47.7954 24.375,47.9974 C24.317,47.9994 24.26,48.0004 24.203,48.0004 L24.203,48.0004 Z" role="presentation" data-reactid="587">
                                            </path>
                                        </svg>
                                    </div>

                                    <div class="_1tu07i3a" data-reactid="588" style="padding-left: 15px;">
                                        <h4 class="_16ni8zai m-b-0" data-reactid="589">
                                            100% online
                                        </h4>
                                        <div class="font-sm text-secondary" data-reactid="590">
                                            Get started now and learn on your own schedule.
                                        </div>
                                    </div>
                                </li>

                                <li class="feature-item p-b--24">
                                    <div class="_1dfpihp m-x-1s m-b-1s m-r-1" data-reactid="584">
                                        <svg class="bi bi-view-stacked" width="1.5em" height="1.5em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" d="M3 0h10a2 2 0 012 2v3a2 2 0 01-2 2H3a2 2 0 01-2-2V2a2 2 0 012-2zm0 1a1 1 0 00-1 1v3a1 1 0 001 1h10a1 1 0 001-1V2a1 1 0 00-1-1H3zm0 8h10a2 2 0 012 2v3a2 2 0 01-2 2H3a2 2 0 01-2-2v-3a2 2 0 012-2zm0 1a1 1 0 00-1 1v3a1 1 0 001 1h10a1 1 0 001-1v-3a1 1 0 00-1-1H3z" clip-rule="evenodd"/>
                                        </svg>
                                    </div>

                                    <div class="_1tu07i3a" data-reactid="588" style="padding-left: 15px;">
                                        <h4 class="_16ni8zai m-b-0" data-reactid="589">
                                            Course 1 of 5 in the program
                                        </h4>
                                    </div>
                                </li>

                                <li class="feature-item p-b--24">
                                    <div class="_1dfpihp m-x-1s m-b-1s m-r-1" data-reactid="584">
                                        <svg class="bi bi-table" width="1.5em" height="1.5em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" d="M14 1H2a1 1 0 00-1 1v12a1 1 0 001 1h12a1 1 0 001-1V2a1 1 0 00-1-1zM2 0a2 2 0 00-2 2v12a2 2 0 002 2h12a2 2 0 002-2V2a2 2 0 00-2-2H2z" clip-rule="evenodd"/>
                                            <path fill-rule="evenodd" d="M15 4H1V3h14v1z" clip-rule="evenodd"/>
                                            <path fill-rule="evenodd" d="M5 15.5v-14h1v14H5zm5 0v-14h1v14h-1z" clip-rule="evenodd"/>
                                            <path fill-rule="evenodd" d="M15 8H1V7h14v1zm0 4H1v-1h14v1z" clip-rule="evenodd"/>
                                            <path d="M0 2a2 2 0 012-2h12a2 2 0 012 2v2H0V2z"/>
                                        </svg>
                                    </div>

                                    <div class="_1tu07i3a" data-reactid="588" style="padding-left: 15px;">
                                        <h4 class="_16ni8zai m-b-0" data-reactid="589">
                                            Flexible deadlines
                                        </h4>

                                        <div class="font-sm text-secondary" data-reactid="590">
                                            Set deadlines according to your schedule.
                                        </div>
                                    </div>
                                </li>

                                <li class="feature-item p-b--24">
                                    <div class="_1dfpihp m-x-1s m-b-1s m-r-1" data-reactid="584">
                                        <svg class="bi bi-clock-history" width="1.5em" height="1.5em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" d="M8.515 1.019A7 7 0 008 1V0a8 8 0 01.589.022l-.074.997zm2.004.45a7.003 7.003 0 00-.985-.299l.219-.976c.383.086.76.2 1.126.342l-.36.933zm1.37.71a7.01 7.01 0 00-.439-.27l.493-.87a8.025 8.025 0 01.979.654l-.615.789a6.996 6.996 0 00-.418-.302zm1.834 1.79a6.99 6.99 0 00-.653-.796l.724-.69c.27.285.52.59.747.91l-.818.576zm.744 1.352a7.08 7.08 0 00-.214-.468l.893-.45a7.976 7.976 0 01.45 1.088l-.95.313a7.023 7.023 0 00-.179-.483zm.53 2.507a6.991 6.991 0 00-.1-1.025l.985-.17c.067.386.106.778.116 1.17l-1 .025zm-.131 1.538c.033-.17.06-.339.081-.51l.993.123a7.957 7.957 0 01-.23 1.155l-.964-.267c.046-.165.086-.332.12-.501zm-.952 2.379c.184-.29.346-.594.486-.908l.914.405c-.16.36-.345.706-.555 1.038l-.845-.535zm-.964 1.205c.122-.122.239-.248.35-.378l.758.653a8.073 8.073 0 01-.401.432l-.707-.707z" clip-rule="evenodd"/>
                                            <path fill-rule="evenodd" d="M8 1a7 7 0 104.95 11.95l.707.707A8.001 8.001 0 118 0v1z" clip-rule="evenodd"/>
                                            <path fill-rule="evenodd" d="M7.5 3a.5.5 0 01.5.5v5.21l3.248 1.856a.5.5 0 01-.496.868l-3.5-2A.5.5 0 017 9V3.5a.5.5 0 01.5-.5z" clip-rule="evenodd"/>
                                        </svg>
                                    </div>

                                    <div class="_1tu07i3a" data-reactid="588" style="padding-left: 15px;">
                                        <h4 class="_16ni8zai m-b-0" data-reactid="589">
                                            Approx 12 hours to complete
                                        </h4>

                                        <div class="font-sm text-secondary" data-reactid="590">
                                            Estimated load: 2-4 hours / week
                                        </div>
                                    </div>
                                </li>
                                <div class="Skills m-y-2 p-x-2 p-t-1 p-b-2 border-a" style="border-radius:4px;" data-reactid="532">
                                    <h3 class="_1fe1gic7 text-secondary text-uppercase m-b-2" data-reactid="533">
                                        Acquired Skills
                                    </h3>
                                    <div class="_t6niqc3" data-reactid="534">
                                    <span class="_rsc0bd m-r-1s m-b-1s" style="height:1.875rem;line-height:1.5rem;font-size:0.875rem;background-color:#e2ffb3;" title="Python Programming" data-reactid="535">
                                        <span class="_x4x75x" data-reactid="536"><span class="_1q9sh65" data-reactid="537">
                                                Python Programming /
                                            </span>
                                        </span>
                                    </span>
                                        <span class="_rsc0bd m-r-1s m-b-1s" style="height:1.875rem;line-height:1.5rem;font-size:0.875rem;background-color:#e2ffb3;" title="Numpy" data-reactid="538">
                                        <span class="_x4x75x" data-reactid="539">
                                            <span class="_1q9sh65" data-reactid="540">
                                                Numpy /
                                            </span>
                                        </span>
                                    </span>
                                        <span class="_rsc0bd m-r-1s m-b-1s" style="height:1.875rem;line-height:1.5rem;font-size:0.875rem;background-color:#e2ffb3;" title="Pandas" data-reactid="541">
                                        <span class="_x4x75x" data-reactid="542">
                                            <span class="_1q9sh65" data-reactid="543">
                                                Pandas /
                                            </span>
                                        </span>
                                    </span>
                                        <span class="_rsc0bd m-r-1s m-b-1s" style="height:1.875rem;line-height:1.5rem;font-size:0.875rem;background-color:#e2ffb3;" title="Data Cleansing" data-reactid="544">
                                        <span class="_x4x75x" data-reactid="545">
                                            <span class="_1q9sh65" data-reactid="546">
                                                Data Cleansing
                                            </span>
                                        </span>
                                    </span>
                                    </div>
                                </div>
                                <div>
                                    <p><a class="btn btn-secondary" href="<?php echo e(url('/data')); ?>" role="button"  style="background-color: #a2e9e9; border-color:#a2e9e9; color:#353b44 ; ">View details >></a></p>
                                </div>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<br>
<footer class="container" >
    <p> <a class="navbar-brand" href="https://www.instagram.com/vmiinv" style="color: darkgrey">
            <svg class="bi bi-at" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" d="M13.106 7.222c0-2.967-2.249-5.032-5.482-5.032-3.35 0-5.646 2.318-5.646 5.702 0 3.493 2.235 5.708 5.762 5.708.862 0 1.689-.123 2.304-.335v-.862c-.43.199-1.354.328-2.29.328-2.926 0-4.813-1.88-4.813-4.798 0-2.844 1.921-4.881 4.594-4.881 2.735 0 4.608 1.688 4.608 4.156 0 1.682-.554 2.769-1.416 2.769-.492 0-.772-.28-.772-.76V5.206H8.923v.834h-.11c-.266-.595-.881-.964-1.6-.964-1.4 0-2.378 1.162-2.378 2.823 0 1.737.957 2.906 2.379 2.906.8 0 1.415-.39 1.709-1.087h.11c.081.67.703 1.148 1.503 1.148 1.572 0 2.57-1.415 2.57-3.643zm-7.177.704c0-1.197.54-1.907 1.456-1.907.93 0 1.524.738 1.524 1.907S8.308 9.84 7.371 9.84c-.895 0-1.442-.725-1.442-1.914z" clip-rule="evenodd"/>
            </svg>
            vmiinv
        </a>

        <a class="navbar-brand" href="https://www.instagram.com/beksultankarl" style="color: darkgrey"  >
            <svg class="bi bi-at" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" d="M13.106 7.222c0-2.967-2.249-5.032-5.482-5.032-3.35 0-5.646 2.318-5.646 5.702 0 3.493 2.235 5.708 5.762 5.708.862 0 1.689-.123 2.304-.335v-.862c-.43.199-1.354.328-2.29.328-2.926 0-4.813-1.88-4.813-4.798 0-2.844 1.921-4.881 4.594-4.881 2.735 0 4.608 1.688 4.608 4.156 0 1.682-.554 2.769-1.416 2.769-.492 0-.772-.28-.772-.76V5.206H8.923v.834h-.11c-.266-.595-.881-.964-1.6-.964-1.4 0-2.378 1.162-2.378 2.823 0 1.737.957 2.906 2.379 2.906.8 0 1.415-.39 1.709-1.087h.11c.081.67.703 1.148 1.503 1.148 1.572 0 2.57-1.415 2.57-3.643zm-7.177.704c0-1.197.54-1.907 1.456-1.907.93 0 1.524.738 1.524 1.907S8.308 9.84 7.371 9.84c-.895 0-1.442-.725-1.442-1.914z" clip-rule="evenodd"/>
            </svg>
            beksultankral
        </a>
    </p>
    <p>
        <svg class="bi bi-chat-square-dots" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" d="M14 1H2a1 1 0 00-1 1v8a1 1 0 001 1h2.5a2 2 0 011.6.8L8 14.333 9.9 11.8a2 2 0 011.6-.8H14a1 1 0 001-1V2a1 1 0 00-1-1zM2 0a2 2 0 00-2 2v8a2 2 0 002 2h2.5a1 1 0 01.8.4l1.9 2.533a1 1 0 001.6 0l1.9-2.533a1 1 0 01.8-.4H14a2 2 0 002-2V2a2 2 0 00-2-2H2z" clip-rule="evenodd"/>
            <path d="M5 6a1 1 0 11-2 0 1 1 0 012 0zm4 0a1 1 0 11-2 0 1 1 0 012 0zm4 0a1 1 0 11-2 0 1 1 0 012 0z"/>
        </svg>
        <a href="https://api.whatsapp.com/send?phone=87472485570&text=Hello!" style="color:darkgrey">Whatsapp</a>

    </p>
    <p>© 2020y. <a class="float-right"href="#" style="color:#00d8d8">Back to top</a></p>

</footer>
<script>
    /* When the user clicks on the button,
    toggle between hiding and showing the dropdown content */
    function myFunction() {
        document.getElementById("myDropdown").classList.toggle("show");
    }

    // Close the dropdown if the user clicks outside of it
    window.onclick = function(event) {
        if (!event.target.matches('.dropbtn')) {
            var dropdowns = document.getElementsByClassName("dropdown-content");
            var i;
            for (i = 0; i < dropdowns.length; i++) {
                var openDropdown = dropdowns[i];
                if (openDropdown.classList.contains('show')) {
                    openDropdown.classList.remove('show');
                }
            }
        }
    }
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\project\resources\views/data.blade.php ENDPATH**/ ?>