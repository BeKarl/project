<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <!-- Styles -->
    <style>

        #img003{
            position: absolute;
            transform: rotate(180deg);
            top:72px;
            left: 250px;
        }
        #img002{
            position: absolute;
            top: 370px;
        }
        .img001{
            position: absolute;
            width: 300px;
            left: 900px;
            top: 72px;
        }
        .btn-group-lg>.btn, .btn-lg {
            padding: .5rem 1rem;
            font-size: 1.25rem;
            line-height: 1.5;
            border-radius: .3rem;
            background-color: #353b44;
            border-style: none;
        }
        #navbarSupportedContent{
            display: flex;
            -webkit-box-align: center;
            align-items: center;
        }

        .dropbtn {
            color: white;
            padding: 16px;
            font-size: 16px;
            border: none;
            cursor: pointer;
        }

        /*.dropbtn:hover, .dropbtn:focus {*/
        /*    background-color: #3e8e41;*/
        /*}*/

        .dropdown {
            float: right;
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f1f1f1;
            min-width: 160px;
            overflow: auto;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            right: 0;
            z-index: 1;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown a:hover {background-color: #ddd;}

        .show {display: block;}

    </style>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

</head>
<body >
<nav class="navbar navbar-expand-lg navbar-light bg-light">

    <nav class="navbar navbar-dark bg-light">
        <a class="navbar-brand" href="#" style="color: #303a44">
            <svg class="bi bi-intersect" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg" style="color:#a2e9e9;">
                <path fill-rule="evenodd" d="M12 4v6.5a1.5 1.5 0 01-1.5 1.5H4V5.5A1.5 1.5 0 015.5 4H12z" clip-rule="evenodd"/>
                <path fill-rule="evenodd" d="M14.5 5h-9a.5.5 0 00-.5.5v9a.5.5 0 00.5.5h9a.5.5 0 00.5-.5v-9a.5.5 0 00-.5-.5zm-9-1A1.5 1.5 0 004 5.5v9A1.5 1.5 0 005.5 16h9a1.5 1.5 0 001.5-1.5v-9A1.5 1.5 0 0014.5 4h-9z" clip-rule="evenodd"/>
                <path fill-rule="evenodd" d="M10.5 1h-9a.5.5 0 00-.5.5v9a.5.5 0 00.5.5h9a.5.5 0 00.5-.5v-9a.5.5 0 00-.5-.5zm-9-1A1.5 1.5 0 000 1.5v9A1.5 1.5 0 001.5 12h9a1.5 1.5 0 001.5-1.5v-9A1.5 1.5 0 0010.5 0h-9z" clip-rule="evenodd"/>
            </svg>
            A.B.P.
        </a>
    </nav>

    <div class="dropdown">
        <button onclick="myFunction()" class="dropbtn"> <span class="navbar-toggler-icon"></span></button>
        <div id="myDropdown" class="dropdown-content">
            <p><a class="btn btn-secondary" href="<?php echo e(url('/home')); ?>" role="button"  style="background-color: #a2e9e9; border-color:#a2e9e9; color:#353b44 ; ">View Calendar >></a></p>
        </div>
    </div>


    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.Home', 'Home')); ?>

                </a>
            </li>


        </ul>

        <!-- Right Side Of Navbar -->
        <ul class="navbar-nav ml-auto">
            <!-- Authentication Links -->
            <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                </li>
                <?php if(Route::has('register')): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                    </li>
                <?php endif; ?>
            <?php else: ?>
                
                <a id="navbarDropdown" class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                </a>

                
                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                    <?php echo e(__('Logout')); ?>

                </a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
                
                
            <?php endif; ?>
        </ul>
    </div>
</nav>













<main role="main">

    <!-- Main jumbotron for a primary marketing message or call to action -->

    <div class="jumbotron"style="background-color: #daf7ff;">
        <img id="img003" src="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://s3.amazonaws.com/coursera_assets/front-page-story/secondary-consumer-cta/red-dotted-half-circle.png?auto=format%2Ccompress&amp;dpr=1&amp;w=&amp;h=90" srcset="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://s3.amazonaws.com/coursera_assets/front-page-story/secondary-consumer-cta/red-dotted-half-circle.png?auto=format%2Ccompress&amp;dpr=2&amp;w=&amp;h=90 2x, https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://s3.amazonaws.com/coursera_assets/front-page-story/secondary-consumer-cta/red-dotted-half-circle.png?auto=format%2Ccompress&amp;dpr=3&amp;w=&amp;h=90 3x" style="max-height:90px;" alt="" data-reactid="481">
        <img id="img002" src="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://s3.amazonaws.com/coursera_assets/front-page-story/achieve-your-goals/blue-dotted-blob-half.png?auto=format%2Ccompress&amp;dpr=1&amp;w=&amp;h=64" srcset="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://s3.amazonaws.com/coursera_assets/front-page-story/achieve-your-goals/blue-dotted-blob-half.png?auto=format%2Ccompress&amp;dpr=2&amp;w=&amp;h=64 2x, https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://s3.amazonaws.com/coursera_assets/front-page-story/achieve-your-goals/blue-dotted-blob-half.png?auto=format%2Ccompress&amp;dpr=3&amp;w=&amp;h=64 3x" style="max-height:64px;" alt="" data-reactid="286">
        <font color="#daf7ff"><div class="container">
                <h1 class="display-3" style="color: #303a44; font-family: Appetite;">Your path to success!</h1>
                <p style="color: #303a44; font-size: 20px; font-weight: bold;">Develop skills with online courses, certifications and diplomas<br>
                    from top universities and companies in the world.</p>
                <p><a class="btn btn-primary btn-lg" href="<?php echo e(route('register')); ?>" role="button" style="background-color: #a2e9e9; border-color:#a2e9e9; color:#353b44 ; ">Join for free »</a></p>
            </div>
        </font>
        <div class="img001">
            <img src="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://s3.amazonaws.com/coursera_assets/front-page-story/achieve-your-goals/pinkish-half-circle.svg?auto=format%2Ccompress&amp;dpr=1&amp;w=&amp;h=50" srcset="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://s3.amazonaws.com/coursera_assets/front-page-story/achieve-your-goals/pinkish-half-circle.svg?auto=format%2Ccompress&amp;dpr=2&amp;w=&amp;h=50 2x, https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://s3.amazonaws.com/coursera_assets/front-page-story/achieve-your-goals/pinkish-half-circle.svg?auto=format%2Ccompress&amp;dpr=3&amp;w=&amp;h=50 3x" style="max-height:50px;" alt="" data-reactid="274">
            <img src="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://s3.amazonaws.com/coursera_assets/front-page-story/achieve-your-goals/promoStat.png?auto=format%2Ccompress&amp;dpr=1&amp;w=&amp;h=250" srcset="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://s3.amazonaws.com/coursera_assets/front-page-story/achieve-your-goals/promoStat.png?auto=format%2Ccompress&amp;dpr=2&amp;w=&amp;h=250 2x, https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://s3.amazonaws.com/coursera_assets/front-page-story/achieve-your-goals/promoStat.png?auto=format%2Ccompress&amp;dpr=3&amp;w=&amp;h=250 3x" style="max-height:250px;" alt="Три изображения-баннера с улыбающимися людьми" data-reactid="276">
        </div>
    </div>

    <div class="container justify-content-center ">
        <!-- Example row of columns -->
        <div class="row featurette justify-content-center">
            <div class="col-md-7">
                <h2 class="featurette-heading">Earn an Ivy League CS Master’s designed for non-CS majors</h2>
                <p class="lead">Each specialization has a practical project that must be successfully completed in order to complete the specialization and receive a certificate. If for a practical project in specialization a separate course is provided, before starting it, it is necessary to complete all other courses. When  complete the practical project, you will receive a certificate that you can share with potential employers and colleagues. </p>
                <p><a class="btn btn-secondary" href="<?php echo e(url('/ml')); ?>" role="button"  style="background-color: #a2e9e9; border-color:#a2e9e9; color:#353b44 ; ">View details >></a></p>
            </div>
            <div class="col-md-5" style="left: 120px">
                <img style="width: 300px; height: 300px;" src="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://coursera-course-photos.s3.amazonaws.com/ec/d59300d68e11e8bdbca3029ecf1978/coursera.jpg?auto=format%2Ccompress&dpr=1">
            </div>
        </div>
        <br>
        <div class="row featurette justify-content-center">
            <div class="col-md-7 order-md-2">
                <h2 class="featurette-heading">Programming for Everybody (Getting Started with Python)</h2>
                <p class="lead">This cource aims to teach everyone the basics computering using Python. We cover the basics of how one constructs a program from a series of simple instructiob in Python. The cource has no pre-requisites and avoids all but the simples mathematics. Anyne with moderate computer experience should be able to master the material in this cource. This cource will cover vhapters 1-15 ofthe textbook "python for everyone"</p>
                <p ><a class="btn btn-secondary" href="<?php echo e(url('/pyth')); ?>" role="button"  style="background-color: #a2e9e9; border-color:#a2e9e9; color:#353b44 ; "><< View details</a></p>
            </div>
            <div class="col-md-5 order-md-1">
                <img style="width: 300px; height: 300px;" src="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://coursera-course-photos.s3.amazonaws.com/53/01bee0502a11e58ddc8ff4d6e0523a/pythonnetworkdata_thumbnail_1x1.png?auto=format%2Ccompress&dpr=1">
            </div>
        </div>
        <br>
        <div class="row featurette justify-content-center">
            <div class="col-md-7">
                <h2 class="featurette-heading">Machine learning.Data science.</h2>
                <p class="lead">Machine learning is the science of getting computers to act without being explicitly programmed. In the past decade,machine learning has self-driving cars,and a improved understanding of the human genome.Machine learning is so pervasive today that you probably use it dozens of times a day without knowing it. Many researchers also think it is the best way to make progress towards human-level AI.  In this class, you will learn about the most effective machine learning techniques. </p>
                <p><a class="btn btn-secondary" href="<?php echo e(url('/data')); ?>" role="button"  style="background-color: #a2e9e9; border-color:#a2e9e9; color:#353b44 ; ">View details >></a></p>
            </div>
            <div class="col-md-5" style="left: 120px">
                <img style="width: 300px; height: 300px;" src="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://coursera-course-photos.s3.amazonaws.com/f8/d9a0901e1411e6b4be05fc1f155449/python_datascience_thumbnail_machinelearning_1x1.png?auto=format%2Ccompress&dpr=1">
            </div>
        </div>
    </div> <!-- /container -->

</main>

</body>
<hr>
<footer class="container" >
    <p> <a class="navbar-brand" href="https://www.instagram.com/vmiinv" style="color: darkgrey">
            <svg class="bi bi-at" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" d="M13.106 7.222c0-2.967-2.249-5.032-5.482-5.032-3.35 0-5.646 2.318-5.646 5.702 0 3.493 2.235 5.708 5.762 5.708.862 0 1.689-.123 2.304-.335v-.862c-.43.199-1.354.328-2.29.328-2.926 0-4.813-1.88-4.813-4.798 0-2.844 1.921-4.881 4.594-4.881 2.735 0 4.608 1.688 4.608 4.156 0 1.682-.554 2.769-1.416 2.769-.492 0-.772-.28-.772-.76V5.206H8.923v.834h-.11c-.266-.595-.881-.964-1.6-.964-1.4 0-2.378 1.162-2.378 2.823 0 1.737.957 2.906 2.379 2.906.8 0 1.415-.39 1.709-1.087h.11c.081.67.703 1.148 1.503 1.148 1.572 0 2.57-1.415 2.57-3.643zm-7.177.704c0-1.197.54-1.907 1.456-1.907.93 0 1.524.738 1.524 1.907S8.308 9.84 7.371 9.84c-.895 0-1.442-.725-1.442-1.914z" clip-rule="evenodd"/>
            </svg>
            vmiinv
        </a>

        <a class="navbar-brand" href="https://www.instagram.com/beksultankarl" style="color: darkgrey"  >
            <svg class="bi bi-at" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" d="M13.106 7.222c0-2.967-2.249-5.032-5.482-5.032-3.35 0-5.646 2.318-5.646 5.702 0 3.493 2.235 5.708 5.762 5.708.862 0 1.689-.123 2.304-.335v-.862c-.43.199-1.354.328-2.29.328-2.926 0-4.813-1.88-4.813-4.798 0-2.844 1.921-4.881 4.594-4.881 2.735 0 4.608 1.688 4.608 4.156 0 1.682-.554 2.769-1.416 2.769-.492 0-.772-.28-.772-.76V5.206H8.923v.834h-.11c-.266-.595-.881-.964-1.6-.964-1.4 0-2.378 1.162-2.378 2.823 0 1.737.957 2.906 2.379 2.906.8 0 1.415-.39 1.709-1.087h.11c.081.67.703 1.148 1.503 1.148 1.572 0 2.57-1.415 2.57-3.643zm-7.177.704c0-1.197.54-1.907 1.456-1.907.93 0 1.524.738 1.524 1.907S8.308 9.84 7.371 9.84c-.895 0-1.442-.725-1.442-1.914z" clip-rule="evenodd"/>
            </svg>
            beksultankral
        </a>
    </p>
    <p>
        <svg class="bi bi-chat-square-dots" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" d="M14 1H2a1 1 0 00-1 1v8a1 1 0 001 1h2.5a2 2 0 011.6.8L8 14.333 9.9 11.8a2 2 0 011.6-.8H14a1 1 0 001-1V2a1 1 0 00-1-1zM2 0a2 2 0 00-2 2v8a2 2 0 002 2h2.5a1 1 0 01.8.4l1.9 2.533a1 1 0 001.6 0l1.9-2.533a1 1 0 01.8-.4H14a2 2 0 002-2V2a2 2 0 00-2-2H2z" clip-rule="evenodd"/>
            <path d="M5 6a1 1 0 11-2 0 1 1 0 012 0zm4 0a1 1 0 11-2 0 1 1 0 012 0zm4 0a1 1 0 11-2 0 1 1 0 012 0z"/>
        </svg>
        <a href="https://api.whatsapp.com/send?phone=87472485570&text=Hello!" style="color:darkgrey">Whatsapp</a>

    </p>
    <p>© 2020y. <a class="float-right"href="#" style="color:#00d8d8">Back to top</a></p>

</footer>
<script>
    /* When the user clicks on the button,
    toggle between hiding and showing the dropdown content */
    function myFunction() {
        document.getElementById("myDropdown").classList.toggle("show");
    }

    // Close the dropdown if the user clicks outside of it
    window.onclick = function(event) {
        if (!event.target.matches('.dropbtn')) {
            var dropdowns = document.getElementsByClassName("dropdown-content");
            var i;
            for (i = 0; i < dropdowns.length; i++) {
                var openDropdown = dropdowns[i];
                if (openDropdown.classList.contains('show')) {
                    openDropdown.classList.remove('show');
                }
            }
        }
    }
</script>

</html>
<?php /**PATH C:\xampp\htdocs\project\resources\views/welcome.blade.php ENDPATH**/ ?>