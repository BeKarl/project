<?php $__env->startSection('content'); ?>
    <main role="main">
        <div class="jumbotron"style="background-color: #daf7ff; padding-bottom: 5em! important;">
        <span style="color: #daf7ff; "><div class="container">
                <h1 class="display-3" style="color: #303a44; font-family: Appetite;">Your path to success!</h1>
                <p style="color: #303a44; font-size: 20px; font-weight: bold;">The best training in the world, available in all corners of the globe.</p></div>
        </span>
            <div class="img001">
                <svg style="color:#a2e9e9"  class="bi bi-person-bounding-box" width="10em" height="10em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M1.5 1a.5.5 0 00-.5.5v3a.5.5 0 01-1 0v-3A1.5 1.5 0 011.5 0h3a.5.5 0 010 1h-3zM11 .5a.5.5 0 01.5-.5h3A1.5 1.5 0 0116 1.5v3a.5.5 0 01-1 0v-3a.5.5 0 00-.5-.5h-3a.5.5 0 01-.5-.5zM.5 11a.5.5 0 01.5.5v3a.5.5 0 00.5.5h3a.5.5 0 010 1h-3A1.5 1.5 0 010 14.5v-3a.5.5 0 01.5-.5zm15 0a.5.5 0 01.5.5v3a1.5 1.5 0 01-1.5 1.5h-3a.5.5 0 010-1h3a.5.5 0 00.5-.5v-3a.5.5 0 01.5-.5z" clip-rule="evenodd"/>
                    <path fill-rule="evenodd" d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"/>
                </svg>
            </div>
        </div>

        <hr class="featurette-divider" style=" height:2px; border-width:0; color:gray; background-color: gray; text-align: center; width:80%;">
        <div class="container marketing">

            <!-- Three columns of text below the carousel -->
            <div class="row">
                <div class="col-lg-4">
                    <svg class="bi bi-book " width="10em" height="10em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg" style="padding-left: 60px">
                        <path fill-rule="evenodd" d="M3.214 1.072C4.813.752 6.916.71 8.354 2.146A.5.5 0 018.5 2.5v11a.5.5 0 01-.854.354c-.843-.844-2.115-1.059-3.47-.92-1.344.14-2.66.617-3.452 1.013A.5.5 0 010 13.5v-11a.5.5 0 01.276-.447L.5 2.5l-.224-.447.002-.001.004-.002.013-.006a5.017 5.017 0 01.22-.103 12.958 12.958 0 012.7-.869zM1 2.82v9.908c.846-.343 1.944-.672 3.074-.788 1.143-.118 2.387-.023 3.426.56V2.718c-1.063-.929-2.631-.956-4.09-.664A11.958 11.958 0 001 2.82z" clip-rule="evenodd"/>
                        <path fill-rule="evenodd" d="M12.786 1.072C11.188.752 9.084.71 7.646 2.146A.5.5 0 007.5 2.5v11a.5.5 0 00.854.354c.843-.844 2.115-1.059 3.47-.92 1.344.14 2.66.617 3.452 1.013A.5.5 0 0016 13.5v-11a.5.5 0 00-.276-.447L15.5 2.5l.224-.447-.002-.001-.004-.002-.013-.006-.047-.023a12.582 12.582 0 00-.799-.34 12.96 12.96 0 00-2.073-.609zM15 2.82v9.908c-.846-.343-1.944-.672-3.074-.788-1.143-.118-2.387-.023-3.426.56V2.718c1.063-.929 2.631-.956 4.09-.664A11.956 11.956 0 0115 2.82z" clip-rule="evenodd"/>
                        <title>Placeholder</title>
                    </svg>
                    <h2>Gain knowledge</h2>
                    <p>Already today you can start viewing the lectures of the best teachers in such subjects as business, computer science, data science, and language learning.</p>
                </div><!-- /.col-lg-4 -->
                <div class="col-lg-4">
                    <svg class="bi bi-card-checklist" width="10em" height="10em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg" style="padding-left: 60px">
                        <path fill-rule="evenodd" d="M14.5 3h-13a.5.5 0 00-.5.5v9a.5.5 0 00.5.5h13a.5.5 0 00.5-.5v-9a.5.5 0 00-.5-.5zm-13-1A1.5 1.5 0 000 3.5v9A1.5 1.5 0 001.5 14h13a1.5 1.5 0 001.5-1.5v-9A1.5 1.5 0 0014.5 2h-13z" clip-rule="evenodd"/>
                        <path fill-rule="evenodd" d="M7 5.5a.5.5 0 01.5-.5h5a.5.5 0 010 1h-5a.5.5 0 01-.5-.5zm-1.496-.854a.5.5 0 010 .708l-1.5 1.5a.5.5 0 01-.708 0l-.5-.5a.5.5 0 11.708-.708l.146.147 1.146-1.147a.5.5 0 01.708 0zM7 9.5a.5.5 0 01.5-.5h5a.5.5 0 010 1h-5a.5.5 0 01-.5-.5zm-1.496-.854a.5.5 0 010 .708l-1.5 1.5a.5.5 0 01-.708 0l-.5-.5a.5.5 0 01.708-.708l.146.147 1.146-1.147a.5.5 0 01.708 0z" clip-rule="evenodd"/>
                    </svg>                    <h2>Find convenient training options</h2>
                    <p>Choose from a variety of study options, including free courses and higher education at a bargain price. Learn at your own pace, exclusively online.</p>
                </div><!-- /.col-lg-4 -->
                <div class="col-lg-4">
                    <svg class="bi bi-clipboard-data" width="10em" height="10em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg" style="padding-left: 60px" v-bind:>
                        <path fill-rule="evenodd" d="M4 1.5H3a2 2 0 00-2 2V14a2 2 0 002 2h10a2 2 0 002-2V3.5a2 2 0 00-2-2h-1v1h1a1 1 0 011 1V14a1 1 0 01-1 1H3a1 1 0 01-1-1V3.5a1 1 0 011-1h1v-1z" clip-rule="evenodd"/>
                        <path fill-rule="evenodd" d="M9.5 1h-3a.5.5 0 00-.5.5v1a.5.5 0 00.5.5h3a.5.5 0 00.5-.5v-1a.5.5 0 00-.5-.5zm-3-1A1.5 1.5 0 005 1.5v1A1.5 1.5 0 006.5 4h3A1.5 1.5 0 0011 2.5v-1A1.5 1.5 0 009.5 0h-3z" clip-rule="evenodd"/>
                        <path d="M4 11a1 1 0 112 0v1a1 1 0 11-2 0v-1zm6-4a1 1 0 112 0v5a1 1 0 11-2 0V7zM7 9a1 1 0 012 0v3a1 1 0 11-2 0V9z"/>
                    </svg>
                        <h2>Hone your skills</h2>
                        <p>Apply your knowledge by completing tests at a comfortable pace and practical projects. Get feedback on your work from other students around the world.</p>
                </div><!-- /.col-lg-4 -->
            </div><!-- /.row -->
            <hr class="featurette-divider" style=" height:2px; border-width:0; color:gray; background-color: gray; text-align: center; ">

            <div class="row featurette">
                <div class="col-md-7" style="padding-top: 100px">
                    <h2 class="featurette-heading">Get documents that confirm your qualifications</h2>
                    <p class="lead"> Professional Certification, MasterTrack ™ Certificate or Diploma.Take the next step towards personal and professional goals with Coursera.We have a solution: world-class training and development programs developed by leading universities and companies. All of this is available at Coursera for Business.</p>
                </div>
                <div class="col-md-5">
                    <div class="rc-ValueProp_image" data-reactid="309"><div class="rc-ValueProp_image-wrap" data-reactid="310"><img src="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://coursera_assets.s3.amazonaws.com/front-page-story/how-it-works/certificates4.png?auto=format%2Ccompress&amp;dpr=1&amp;w=546&amp;h=" srcset="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://coursera_assets.s3.amazonaws.com/front-page-story/how-it-works/certificates4.png?auto=format%2Ccompress&amp;dpr=2&amp;w=546&amp;h= 2x, https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://coursera_assets.s3.amazonaws.com/front-page-story/how-it-works/certificates4.png?auto=format%2Ccompress&amp;dpr=3&amp;w=546&amp;h= 3x" style="max-width:546px;" alt="Фото улыбающегося учащегося Coursera в офисе, за его спиной компьютер с кодом на экране, а на переднем плане&nbsp;— сертификат." data-reactid="311">
                        </div>
                    </div>
                    <title>
                        Placeholder
                    </title>
                </div>
            </div>
            <hr class="featurette-divider" style=" height:2px; border-width:0; color:gray; background-color: gray; text-align: center; ">
        </div>

        <div class="container" style="padding-top: 5em! important;">
            <div class="row justify-content-center">
                <h1>May 2020</h1>
                <table class="table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th scope="col">Week</th>
                        <th scope="col">Monday</th>
                        <th scope="col">Tuesday</th>
                        <th scope="col">Wednesday</th>
                        <th scope="col">Thursday</th>
                        <th scope="col">Friday</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <th scope="row">18</th>
                        <td>27</td>
                        <td>28</td>
                        <td>29</td>
                        <td>30</td>
                        <td><a onclick="myFunction0()">1</a>
                            <div id="myDIV0">
                                A brief tour of the courses
                            </div></td>
                    </tr>
                    <tr>
                        <th scope="row">19</th>
                        <td><a onclick="myFunction0()">4</a>
                            <div id="myDIV1">
                                8:00-11:00 - CS Master’s<br> 11:00-14:00 - Python<br> 15:00-18:00 Machine learning
                            </div></td>
                        <td><a onclick="myFunction0()">5</a>
                            <div id="myDIV2">
                                Whole day - Python
                            </div></td>
                        <td><a onclick="myFunction0()">6</a>
                            <div id="myDIV3">
                                11:00-17:00 - Machine learning
                            </div></td>
                        <td><a onclick="myFunction0()">7</a>
                            <div id="myDIV4">

                            </div></td>
                        <td><a onclick="myFunction0()">8</a>
                            <div id="myDIV5">
                                14:00-18:00 CS Master’s
                            </div></td>
                    </tr>
                    <tr>
                        <th scope="row">20</th>
                        <td><a onclick="myFunction0()">11</a>
                            <div id="myDIV6">
                                9:00-13:00 CS Master’s<br>
                                14:00-18:00 Machine learning<br>
                            </div></td>
                        <td><a onclick="myFunction0()">12</a>
                            <div id="myDIV7">
                                10:00 - 14:00 Python<br>
                                11:00 - 17:00 Machine learning<br>
                                14:30 - 19:00 CS Master’s
                            </div></td>
                        <td><a onclick="myFunction0()">13</a>
                            <div id="myDIV8">
                                11:00 - 17:00 Python<br>
                                10:30 - 15:00 CS Master’s
                            </div></td>
                        <td><a onclick="myFunction0()">14</a>
                            <div id="myDIV9">
                                11:00 - 17:00 Machine learning<br>
                                14:30 - 19:00 CS Master’s
                            </div></td>
                        <td><a onclick="myFunction0()">15</a>
                            <div id="myDIV10">
                                10:00 - 14:00 Python<br>
                                11:00 - 17:00 Machine learning
                            </div></td>
                    </tr>
                    <tr>
                        <th scope="row">21</th>
                        <td><a onclick="myFunction0()">18</a>
                            <div id="myDIV11">
                                10:00 - 15:00 Python<br>
                                9:00 - 17:00 Machine learning<br>
                                11:30 - 16:30 CS Master’s
                            </div></td>
                        <td><a onclick="myFunction0()">19</a>
                            <div id="myDIV12">

                            </div></td>
                        <td><a onclick="myFunction0()">20</a>
                            <div id="myDIV13">
                                10:00 - 14:00 Python<br>
                                14:30 - 19:00 CS Master’s
                            </div></td>
                        <td><a onclick="myFunction0()">21</a>
                            <div id="myDIV14">
                                10:00 - 14:00 Python<br>
                                11:00 - 17:00 Machine learning
                            </div></td>
                        <td><a onclick="myFunction0()">22</a>
                            <div id="myDIV15">
                                10:00 - 14:00 Python<br>
                                11:00 - 17:00 Machine learning<br>
                                14:30 - 19:00 CS Master’s
                            </div></td>
                    </tr>
                    <tr>
                        <th scope="row">22</th>
                        <td><a onclick="myFunction0()">23</a>
                            <div id="myDIV16">
                                10:00 - 14:00 Python<br>
                                11:00 - 17:00 Machine learning<br>
                                14:30 - 19:00 CS Master’s
                            </div></td>
                        <td><a onclick="myFunction0()">24</a>
                            <div id="myDIV17">
                                10:00 - 14:00 Python<br>
                                11:00 - 17:00 Machine learning<br>
                                14:30 - 19:00 CS Master’s
                            </div></td>
                        <td><a onclick="myFunction0()">25</a>
                            <div id="myDIV18">

                            </div></td>
                        <td><a onclick="myFunction0()">26</a>
                            <div id="myDIV19">
                                10:00 - 14:00 Python<br>
                                11:00 - 17:00 Machine learning<br>
                                14:30 - 19:00 CS Master’s
                            </div></td>
                        <td><a onclick="myFunction0()">27</a>
                            <div id="myDIV20">
                                10:00 - 14:00 Python<br>
                                11:00 - 17:00 Machine learning<br>
                                14:30 - 19:00 CS Master’s
                            </div></td>
                    </tr>
                    <tr>
                        <th scope="row">23</th>
                        <td>1</td>
                        <td>2</td>
                        <td>3</td>
                        <td>4</td>
                        <td>5</td>
                    </tr>
                    </tbody>
                </table>
            </div>
            </div>
        <script>
            function myFunction0() {
                var x = document.getElementById("myDIV0");
                if (x.style.display === "none") {
                    x.style.display = "block";
                } else {
                    x.style.display = "none";
                }
                var x = document.getElementById("myDIV1");
                if (x.style.display === "none") {
                    x.style.display = "block";
                } else {
                    x.style.display = "none";
                }
                var x = document.getElementById("myDIV2");
                if (x.style.display === "none") {
                    x.style.display = "block";
                } else {
                    x.style.display = "none";
                }
                var x = document.getElementById("myDIV3");
                if (x.style.display === "none") {
                    x.style.display = "block";
                } else {
                    x.style.display = "none";
                }
                var x = document.getElementById("myDIV4");
                if (x.style.display === "none") {
                    x.style.display = "block";
                } else {
                    x.style.display = "none";
                }
                var x = document.getElementById("myDIV5");
                if (x.style.display === "none") {
                    x.style.display = "block";
                } else {
                    x.style.display = "none";
                }
                var x = document.getElementById("myDIV6");
                if (x.style.display === "none") {
                    x.style.display = "block";
                } else {
                    x.style.display = "none";
                }
                var x = document.getElementById("myDIV7");
                if (x.style.display === "none") {
                    x.style.display = "block";
                } else {
                    x.style.display = "none";
                }
                var x = document.getElementById("myDIV8");
                if (x.style.display === "none") {
                    x.style.display = "block";
                } else {
                    x.style.display = "none";
                }
                var x = document.getElementById("myDIV9");
                if (x.style.display === "none") {
                    x.style.display = "block";
                } else {
                    x.style.display = "none";
                }
                var x = document.getElementById("myDIV10");
                if (x.style.display === "none") {
                    x.style.display = "block";
                } else {
                    x.style.display = "none";
                }
                var x = document.getElementById("myDIV11");
                if (x.style.display === "none") {
                    x.style.display = "block";
                } else {
                    x.style.display = "none";
                }
                var x = document.getElementById("myDIV12");
                if (x.style.display === "none") {
                    x.style.display = "block";
                } else {
                    x.style.display = "none";
                }
                var x = document.getElementById("myDIV13");
                if (x.style.display === "none") {
                    x.style.display = "block";
                } else {
                    x.style.display = "none";
                }
                var x = document.getElementById("myDIV14");
                if (x.style.display === "none") {
                    x.style.display = "block";
                } else {
                    x.style.display = "none";
                }
                var x = document.getElementById("myDIV15");
                if (x.style.display === "none") {
                    x.style.display = "block";
                } else {
                    x.style.display = "none";
                }
                var x = document.getElementById("myDIV16");
                if (x.style.display === "none") {
                    x.style.display = "block";
                } else {
                    x.style.display = "none";
                }
                var x = document.getElementById("myDIV17");
                if (x.style.display === "none") {
                    x.style.display = "block";
                } else {
                    x.style.display = "none";
                }
                var x = document.getElementById("myDIV18");
                if (x.style.display === "none") {
                    x.style.display = "block";
                } else {
                    x.style.display = "none";
                }
                var x = document.getElementById("myDIV19");
                if (x.style.display === "none") {
                    x.style.display = "block";
                } else {
                    x.style.display = "none";
                }
                var x = document.getElementById("myDIV20");
                if (x.style.display === "none") {
                    x.style.display = "block";
                } else {
                    x.style.display = "none";
                }
            }
            // function myFunction1() {
            //     var x = document.getElementById("myDIV1");
            //     if (x.style.display === "none") {
            //         x.style.display = "block";
            //     } else {
            //         x.style.display = "none";
            //     }
            // }
            // function myFunction2() {
            //     var x = document.getElementById("myDIV2");
            //     if (x.style.display === "none") {
            //         x.style.display = "block";
            //     } else {
            //         x.style.display = "none";
            //     }
            // }
            // function myFunction3() {
            //     var x = document.getElementById("myDIV3");
            //     if (x.style.display === "none") {
            //         x.style.display = "block";
            //     } else {
            //         x.style.display = "none";
            //     }
            // }
            // function myFunction4() {
            //     var x = document.getElementById("myDIV4");
            //     if (x.style.display === "none") {
            //         x.style.display = "block";
            //     } else {
            //         x.style.display = "none";
            //     }
            // }
            // function myFunction5() {
            //     var x = document.getElementById("myDIV5");
            //     if (x.style.display === "none") {
            //         x.style.display = "block";
            //     } else {
            //         x.style.display = "none";
            //     }
            // }
            // function myFunction6() {
            //     var x = document.getElementById("myDIV6");
            //     if (x.style.display === "none") {
            //         x.style.display = "block";
            //     } else {
            //         x.style.display = "none";
            //     }
            // }
            // function myFunction7() {
            //     var x = document.getElementById("myDIV7");
            //     if (x.style.display === "none") {
            //         x.style.display = "block";
            //     } else {
            //         x.style.display = "none";
            //     }
            // }
            // function myFunction8() {
            //     var x = document.getElementById("myDIV8");
            //     if (x.style.display === "none") {
            //         x.style.display = "block";
            //     } else {
            //         x.style.display = "none";
            //     }
            // }
            // function myFunction9() {
            //     var x = document.getElementById("myDIV9");
            //     if (x.style.display === "none") {
            //         x.style.display = "block";
            //     } else {
            //         x.style.display = "none";
            //     }
            // }
            // function myFunction10() {
            //     var x = document.getElementById("myDIV10");
            //     if (x.style.display === "none") {
            //         x.style.display = "block";
            //     } else {
            //         x.style.display = "none";
            //     }
            // }
            // function myFunction11() {
            //     var x = document.getElementById("myDIV11");
            //     if (x.style.display === "none") {
            //         x.style.display = "block";
            //     } else {
            //         x.style.display = "none";
            //     }
            // }
            // function myFunction12() {
            //     var x = document.getElementById("myDIV12");
            //     if (x.style.display === "none") {
            //         x.style.display = "block";
            //     } else {
            //         x.style.display = "none";
            //     }
            // }
            // function myFunction13() {
            //     var x = document.getElementById("myDIV13");
            //     if (x.style.display === "none") {
            //         x.style.display = "block";
            //     } else {
            //         x.style.display = "none";
            //     }
            // }
            // function myFunction14() {
            //     var x = document.getElementById("myDIV14");
            //     if (x.style.display === "none") {
            //         x.style.display = "block";
            //     } else {
            //         x.style.display = "none";
            //     }
            // }
            // function myFunction15() {
            //     var x = document.getElementById("myDIV15");
            //     if (x.style.display === "none") {
            //         x.style.display = "block";
            //     } else {
            //         x.style.display = "none";
            //     }
            // }
            // function myFunction16() {
            //     var x = document.getElementById("myDIV16");
            //     if (x.style.display === "none") {
            //         x.style.display = "block";
            //     } else {
            //         x.style.display = "none";
            //     }
            // }
            // function myFunction17() {
            //     var x = document.getElementById("myDIV17");
            //     if (x.style.display === "none") {
            //         x.style.display = "block";
            //     } else {
            //         x.style.display = "none";
            //     }
            // }
            // function myFunction18() {
            //     var x = document.getElementById("myDIV18");
            //     if (x.style.display === "none") {
            //         x.style.display = "block";
            //     } else {
            //         x.style.display = "none";
            //     }
            // }
            // function myFunction19() {
            //     var x = document.getElementById("myDIV19");
            //     if (x.style.display === "none") {
            //         x.style.display = "block";
            //     } else {
            //         x.style.display = "none";
            //     }
            // }
            // function myFunction20() {
            //     var x = document.getElementById("myDIV20");
            //     if (x.style.display === "none") {
            //         x.style.display = "block";
            //     } else {
            //         x.style.display = "none";
            //     }
            // }
        </script>
    </main>
    <footer class="container" >
        <p> <a class="navbar-brand" href="https://www.instagram.com/vmiinv" style="color: darkgrey">
                <svg class="bi bi-at" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M13.106 7.222c0-2.967-2.249-5.032-5.482-5.032-3.35 0-5.646 2.318-5.646 5.702 0 3.493 2.235 5.708 5.762 5.708.862 0 1.689-.123 2.304-.335v-.862c-.43.199-1.354.328-2.29.328-2.926 0-4.813-1.88-4.813-4.798 0-2.844 1.921-4.881 4.594-4.881 2.735 0 4.608 1.688 4.608 4.156 0 1.682-.554 2.769-1.416 2.769-.492 0-.772-.28-.772-.76V5.206H8.923v.834h-.11c-.266-.595-.881-.964-1.6-.964-1.4 0-2.378 1.162-2.378 2.823 0 1.737.957 2.906 2.379 2.906.8 0 1.415-.39 1.709-1.087h.11c.081.67.703 1.148 1.503 1.148 1.572 0 2.57-1.415 2.57-3.643zm-7.177.704c0-1.197.54-1.907 1.456-1.907.93 0 1.524.738 1.524 1.907S8.308 9.84 7.371 9.84c-.895 0-1.442-.725-1.442-1.914z" clip-rule="evenodd"/>
                </svg>
                vmiinv
            </a>

            <a class="navbar-brand" href="https://www.instagram.com/beksultankarl" style="color: darkgrey"  >
                <svg class="bi bi-at" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M13.106 7.222c0-2.967-2.249-5.032-5.482-5.032-3.35 0-5.646 2.318-5.646 5.702 0 3.493 2.235 5.708 5.762 5.708.862 0 1.689-.123 2.304-.335v-.862c-.43.199-1.354.328-2.29.328-2.926 0-4.813-1.88-4.813-4.798 0-2.844 1.921-4.881 4.594-4.881 2.735 0 4.608 1.688 4.608 4.156 0 1.682-.554 2.769-1.416 2.769-.492 0-.772-.28-.772-.76V5.206H8.923v.834h-.11c-.266-.595-.881-.964-1.6-.964-1.4 0-2.378 1.162-2.378 2.823 0 1.737.957 2.906 2.379 2.906.8 0 1.415-.39 1.709-1.087h.11c.081.67.703 1.148 1.503 1.148 1.572 0 2.57-1.415 2.57-3.643zm-7.177.704c0-1.197.54-1.907 1.456-1.907.93 0 1.524.738 1.524 1.907S8.308 9.84 7.371 9.84c-.895 0-1.442-.725-1.442-1.914z" clip-rule="evenodd"/>
                </svg>
                beksultankral
            </a>
        </p>
        <p>
            <svg class="bi bi-chat-square-dots" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" d="M14 1H2a1 1 0 00-1 1v8a1 1 0 001 1h2.5a2 2 0 011.6.8L8 14.333 9.9 11.8a2 2 0 011.6-.8H14a1 1 0 001-1V2a1 1 0 00-1-1zM2 0a2 2 0 00-2 2v8a2 2 0 002 2h2.5a1 1 0 01.8.4l1.9 2.533a1 1 0 001.6 0l1.9-2.533a1 1 0 01.8-.4H14a2 2 0 002-2V2a2 2 0 00-2-2H2z" clip-rule="evenodd"/>
                <path d="M5 6a1 1 0 11-2 0 1 1 0 012 0zm4 0a1 1 0 11-2 0 1 1 0 012 0zm4 0a1 1 0 11-2 0 1 1 0 012 0z"/>
            </svg>
            <a href="https://api.whatsapp.com/send?phone=87472485570&text=Hello!" style="color:darkgrey">Whatsapp</a>

        </p>
        <p>© 2020y. <a class="float-right"href="#" style="color:#00d8d8">Back to top</a></p>

    </footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/home.blade.php ENDPATH**/ ?>