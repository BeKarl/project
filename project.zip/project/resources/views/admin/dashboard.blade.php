@extends('layouts.app')

@section('content')
    <div class="container">

        <div class="row justify-content-center">
            <h1>May 2020</h1>
            <table class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th scope="col">Week</th>
                    <th scope="col">Monday</th>
                    <th scope="col">Tuesday</th>
                    <th scope="col">Wednesday</th>
                    <th scope="col">Thursday</th>
                    <th scope="col">Friday</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <th scope="row">18</th>
                    <td>27</td>
                    <td>28</td>
                    <td>29</td>
                    <td>30</td>
                    <td><a onclick="myFunction()">1</a>
                        <div id="myDIV">
                            This is my DIV element.
                        </div>
                    </td>
                </tr>
                <tr>
                    <th scope="row">19</th>
                    <td><a onclick="myFunction1()">4</a>
                        <div id="myDIV1">
                            This is my DIV element.
                        </div></td>
                    <td><a onclick="myFunction2()">5</a>
                        <div id="myDIV2">
                            This is my DIV element.
                        </div></td>
                    <td><a onclick="myFunction3()">6</a>
                        <div id="myDIV3">
                            This is my DIV element.
                        </div></td>
                    <td><a onclick="myFunction4()">7</a>
                        <div id="myDIV4">
                            This is my DIV element.
                        </div></td>
                    <td><a onclick="myFunction5()">8</a>
                        <div id="myDIV5">
                            This is my DIV element.
                        </div></td>
                </tr>
                <tr>
                    <th scope="row">20</th>
                    <td><a onclick="myFunction6()">11</a>
                        <div id="myDIV6">
                            This is my DIV element.
                        </div></td>
                    <td><a onclick="myFunction7()">12</a>
                        <div id="myDIV7">
                            This is my DIV element.
                        </div></td>
                    <td><a onclick="myFunction8()">13</a>
                        <div id="myDIV8">
                            This is my DIV element.
                        </div></td>
                    <td><a onclick="myFunction9()">14</a>
                        <div id="myDIV9">
                            This is my DIV element.
                        </div></td>
                    <td><a onclick="myFunction10()">15</a>
                        <div id="myDIV10">
                            This is my DIV element.
                        </div></td>
                </tr>
                <tr>
                    <th scope="row">21</th>
                    <td><a onclick="myFunction11()">18</a>
                        <div id="myDIV11">
                            This is my DIV element.
                        </div></td>
                    <td><a onclick="myFunction12()">19</a>
                        <div id="myDIV12">
                            This is my DIV element.
                        </div></td>
                    <td><a onclick="myFunction13()">20</a>
                        <div id="myDIV13">
                            This is my DIV element.
                        </div></td>
                    <td><a onclick="myFunction14()">21</a>
                        <div id="myDIV14">
                            This is my DIV element.
                        </div></td>
                    <td><a onclick="myFunction15()">22</a>
                        <div id="myDIV15">
                            This is my DIV element.
                        </div></td>
                </tr>
                <tr>
                    <th scope="row">22</th>
                    <td><a onclick="myFunction16()">23</a>
                        <div id="myDIV16">
                            This is my DIV element.
                        </div></td>
                    <td><a onclick="myFunction17()">24</a>
                        <div id="myDIV17">
                            This is my DIV element.
                        </div></td>
                    <td><a onclick="myFunction18()">25</a>
                        <div id="myDIV18">
                            This is my DIV element.
                        </div></td>
                    <td><a onclick="myFunction19()">26</a>
                        <div id="myDIV19">
                            This is my DIV element.
                        </div></td>
                    <td><a onclick="myFunction20()">27</a>
                        <div id="myDIV20">
                            This is my DIV element.
                        </div></td>
                </tr>
                <tr>
                    <th scope="row">23</th>
                    <td>1</td>
                    <td>2</td>
                    <td>3</td>
                    <td>4</td>
                    <td>5</td>
                </tr>
                </tbody>
            </table>
        </div>
        {{Auth::user()->name}}
    </div>
    <script>
        function myFunction() {
            var x = document.getElementById("myDIV");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
        function myFunction1() {
            var x = document.getElementById("myDIV1");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
        function myFunction2() {
            var x = document.getElementById("myDIV2");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
        function myFunction3() {
            var x = document.getElementById("myDIV3");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
        function myFunction4() {
            var x = document.getElementById("myDIV4");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
        function myFunction5() {
            var x = document.getElementById("myDIV5");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
        function myFunction6() {
            var x = document.getElementById("myDIV6");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
        function myFunction7() {
            var x = document.getElementById("myDIV7");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
        function myFunction8() {
            var x = document.getElementById("myDIV8");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
        function myFunction9() {
            var x = document.getElementById("myDIV9");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
        function myFunction10() {
            var x = document.getElementById("myDIV10");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
        function myFunction11() {
            var x = document.getElementById("myDIV11");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
        function myFunction12() {
            var x = document.getElementById("myDIV12");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
        function myFunction13() {
            var x = document.getElementById("myDIV13");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
        function myFunction14() {
            var x = document.getElementById("myDIV14");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
        function myFunction15() {
            var x = document.getElementById("myDIV15");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
        function myFunction16() {
            var x = document.getElementById("myDIV16");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
        function myFunction17() {
            var x = document.getElementById("myDIV17");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
        function myFunction18() {
            var x = document.getElementById("myDIV18");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
        function myFunction19() {
            var x = document.getElementById("myDIV19");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
        function myFunction20() {
            var x = document.getElementById("myDIV20");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
    </script>
@endsection
