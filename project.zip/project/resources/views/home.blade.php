<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    <link href="{{ URL::asset('css/app.css') }}" rel="'stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <link href="/css/main.css" rel="stylesheet">
</head>
<body>


<nav class="navbar navbar-expand-lg navbar-light" style="background-color: white">

    <nav class="navbar">
        <a class="navbar-brand" href="#" >
            <svg class="bi bi-intersect" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg" style="color: darkgrey; padding-bottom: 5px">
                <path fill-rule="evenodd" d="M12 4v6.5a1.5 1.5 0 01-1.5 1.5H4V5.5A1.5 1.5 0 015.5 4H12z" clip-rule="evenodd"/>
                <path fill-rule="evenodd" d="M14.5 5h-9a.5.5 0 00-.5.5v9a.5.5 0 00.5.5h9a.5.5 0 00.5-.5v-9a.5.5 0 00-.5-.5zm-9-1A1.5 1.5 0 004 5.5v9A1.5 1.5 0 005.5 16h9a1.5 1.5 0 001.5-1.5v-9A1.5 1.5 0 0014.5 4h-9z" clip-rule="evenodd"/>
                <path fill-rule="evenodd" d="M10.5 1h-9a.5.5 0 00-.5.5v9a.5.5 0 00.5.5h9a.5.5 0 00.5-.5v-9a.5.5 0 00-.5-.5zm-9-1A1.5 1.5 0 000 1.5v9A1.5 1.5 0 001.5 12h9a1.5 1.5 0 001.5-1.5v-9A1.5 1.5 0 0010.5 0h-9z" clip-rule="evenodd"/>
            </svg>
            A.B.P.
        </a>
    </nav>

    <div class="dropdown" >
        <button onclick="myFunction()" class="dropbtn" > <span class="navbar-toggler-icon light " style="background-color: white"></span></button>
        <div id="myDropdown" class="dropdown-content">
            <p><a class="btn btn-secondary" href="{{url('/home')}}" role="button"  style="background-color: #a2e9e9; border-color:#a2e9e9; color:#353b44 ; ">View Calendar >></a></p>
        </div>
    </div>


    <div class="collapse navbar-collapse" id="navbarSupportedContent">

        <!-- Right Side Of Navbar -->
        <ul class="navbar-nav ml-auto">
            <!-- Authentication Links -->
            @guest
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
                </li>
                @if (Route::has('register'))
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                    </li>
                @endif
            @else
                {{--                    <li class="nav-item dropdown">--}}
                <a id="navbarDropdown" class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                    {{ Auth::user()->name }} <span class="caret"></span>
                </a>

                {{--                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">--}}
                <a class="dropdown-item" href="{{ route('logout') }}"
                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                    {{ __('Logout') }}
                </a>

                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                    @csrf
                </form>
                {{--                        </div>--}}
                {{--                    </li>--}}
            @endguest
        </ul>
    </div>
</nav>
{{--    @if (Route::has('login'))--}}
{{--        <div class="top-right links">--}}
{{--            @auth--}}
{{--                <a href="{{ url('/home') }}">Home</a>--}}
{{--            @else--}}
{{--                <a href="{{ route('login') }}">Login</a>--}}

{{--                @if (Route::has('register'))--}}
{{--                    <a href="{{ route('register') }}">Register</a>--}}
{{--                @endif--}}
{{--            @endauth--}}
{{--        </div>--}}
{{--    @endif--}}
<main role="main">
    <div class="jumbotron" id="bg2">
        <span style="color: #daf7ff; "><div class="container">
                <h1 class="display-3" style="color: #303a44; font-family: Appetite;">Your path to <br/>success!</h1>
                <p class="paragraf1">The best training in the world, available in all corners     of the globe.</p></div>
        </span>
        <div class="img001">
            <svg   class="bi bi-person-bounding-box" width="13em" height="13em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" d="M1.5 1a.5.5 0 00-.5.5v3a.5.5 0 01-1 0v-3A1.5 1.5 0 011.5 0h3a.5.5 0 010 1h-3zM11 .5a.5.5 0 01.5-.5h3A1.5 1.5 0 0116 1.5v3a.5.5 0 01-1 0v-3a.5.5 0 00-.5-.5h-3a.5.5 0 01-.5-.5zM.5 11a.5.5 0 01.5.5v3a.5.5 0 00.5.5h3a.5.5 0 010 1h-3A1.5 1.5 0 010 14.5v-3a.5.5 0 01.5-.5zm15 0a.5.5 0 01.5.5v3a1.5 1.5 0 01-1.5 1.5h-3a.5.5 0 010-1h3a.5.5 0 00.5-.5v-3a.5.5 0 01.5-.5z" clip-rule="evenodd"/>
                <path fill-rule="evenodd" d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 100-6 3 3 0 000 6z" clip-rule="evenodd"/>
            </svg>
        </div>
    </div>

    <hr class="featurette-divider" style=" height:2px; border-width:0; color:gray; background-color: gray; text-align: center; width:80%;">
    <div class="container marketing">

        <!-- Three columns of text below the carousel -->
        <div class="row">
            <div class="col-lg-4">
                <svg class="bi bi-book " width="10em" height="10em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg" style="padding-left: 60px">
                    <path fill-rule="evenodd" d="M3.214 1.072C4.813.752 6.916.71 8.354 2.146A.5.5 0 018.5 2.5v11a.5.5 0 01-.854.354c-.843-.844-2.115-1.059-3.47-.92-1.344.14-2.66.617-3.452 1.013A.5.5 0 010 13.5v-11a.5.5 0 01.276-.447L.5 2.5l-.224-.447.002-.001.004-.002.013-.006a5.017 5.017 0 01.22-.103 12.958 12.958 0 012.7-.869zM1 2.82v9.908c.846-.343 1.944-.672 3.074-.788 1.143-.118 2.387-.023 3.426.56V2.718c-1.063-.929-2.631-.956-4.09-.664A11.958 11.958 0 001 2.82z" clip-rule="evenodd"/>
                    <path fill-rule="evenodd" d="M12.786 1.072C11.188.752 9.084.71 7.646 2.146A.5.5 0 007.5 2.5v11a.5.5 0 00.854.354c.843-.844 2.115-1.059 3.47-.92 1.344.14 2.66.617 3.452 1.013A.5.5 0 0016 13.5v-11a.5.5 0 00-.276-.447L15.5 2.5l.224-.447-.002-.001-.004-.002-.013-.006-.047-.023a12.582 12.582 0 00-.799-.34 12.96 12.96 0 00-2.073-.609zM15 2.82v9.908c-.846-.343-1.944-.672-3.074-.788-1.143-.118-2.387-.023-3.426.56V2.718c1.063-.929 2.631-.956 4.09-.664A11.956 11.956 0 0115 2.82z" clip-rule="evenodd"/>
                    <title>Placeholder</title>
                </svg>
                <h2>Gain knowledge</h2>
                <p>Already today you can start viewing the lectures of the best teachers in such subjects as business, computer science, data science, and language learning.</p>
            </div><!-- /.col-lg-4 -->
            <div class="col-lg-4">
                <svg class="bi bi-card-checklist" width="10em" height="10em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg" style="padding-left: 60px">
                    <path fill-rule="evenodd" d="M14.5 3h-13a.5.5 0 00-.5.5v9a.5.5 0 00.5.5h13a.5.5 0 00.5-.5v-9a.5.5 0 00-.5-.5zm-13-1A1.5 1.5 0 000 3.5v9A1.5 1.5 0 001.5 14h13a1.5 1.5 0 001.5-1.5v-9A1.5 1.5 0 0014.5 2h-13z" clip-rule="evenodd"/>
                    <path fill-rule="evenodd" d="M7 5.5a.5.5 0 01.5-.5h5a.5.5 0 010 1h-5a.5.5 0 01-.5-.5zm-1.496-.854a.5.5 0 010 .708l-1.5 1.5a.5.5 0 01-.708 0l-.5-.5a.5.5 0 11.708-.708l.146.147 1.146-1.147a.5.5 0 01.708 0zM7 9.5a.5.5 0 01.5-.5h5a.5.5 0 010 1h-5a.5.5 0 01-.5-.5zm-1.496-.854a.5.5 0 010 .708l-1.5 1.5a.5.5 0 01-.708 0l-.5-.5a.5.5 0 01.708-.708l.146.147 1.146-1.147a.5.5 0 01.708 0z" clip-rule="evenodd"/>
                </svg>                    <h2>Find convenient training options</h2>
                <p>Choose from a variety of study options, including free courses and higher education at a bargain price. Learn at your own pace, exclusively online.</p>
            </div><!-- /.col-lg-4 -->
            <div class="col-lg-4">
                <svg class="bi bi-clipboard-data" width="10em" height="10em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg" style="padding-left: 60px" v-bind:>
                    <path fill-rule="evenodd" d="M4 1.5H3a2 2 0 00-2 2V14a2 2 0 002 2h10a2 2 0 002-2V3.5a2 2 0 00-2-2h-1v1h1a1 1 0 011 1V14a1 1 0 01-1 1H3a1 1 0 01-1-1V3.5a1 1 0 011-1h1v-1z" clip-rule="evenodd"/>
                    <path fill-rule="evenodd" d="M9.5 1h-3a.5.5 0 00-.5.5v1a.5.5 0 00.5.5h3a.5.5 0 00.5-.5v-1a.5.5 0 00-.5-.5zm-3-1A1.5 1.5 0 005 1.5v1A1.5 1.5 0 006.5 4h3A1.5 1.5 0 0011 2.5v-1A1.5 1.5 0 009.5 0h-3z" clip-rule="evenodd"/>
                    <path d="M4 11a1 1 0 112 0v1a1 1 0 11-2 0v-1zm6-4a1 1 0 112 0v5a1 1 0 11-2 0V7zM7 9a1 1 0 012 0v3a1 1 0 11-2 0V9z"/>
                </svg>
                <h2>Hone your skills</h2>
                <p>Apply your knowledge by completing tests at a comfortable pace and practical projects. Get feedback on your work from other students around the world.</p>
            </div><!-- /.col-lg-4 -->
        </div><!-- /.row -->
        <hr class="featurette-divider" style=" height:2px; border-width:0; color:gray; background-color: gray; text-align: center; ">

        <div class="row featurette">
            <div class="col-md-7" style="padding-top: 100px">
                <h2 class="featurette-heading">Get documents that confirm your qualifications</h2>
                <p class="lead"> Professional Certification, MasterTrack ™ Certificate or Diploma.Take the next step towards personal and professional goals with Coursera.We have a solution: world-class training and development programs developed by leading universities and companies. All of this is available at Coursera for Business.</p>
            </div>
            <div class="col-md-5">
                <div class="rc-ValueProp_image" data-reactid="309"><div class="rc-ValueProp_image-wrap" data-reactid="310"><img src="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://coursera_assets.s3.amazonaws.com/front-page-story/how-it-works/certificates4.png?auto=format%2Ccompress&amp;dpr=1&amp;w=546&amp;h=" srcset="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://coursera_assets.s3.amazonaws.com/front-page-story/how-it-works/certificates4.png?auto=format%2Ccompress&amp;dpr=2&amp;w=546&amp;h= 2x, https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://coursera_assets.s3.amazonaws.com/front-page-story/how-it-works/certificates4.png?auto=format%2Ccompress&amp;dpr=3&amp;w=546&amp;h= 3x" style="max-width:546px;" alt="Фото улыбающегося учащегося Coursera в офисе, за его спиной компьютер с кодом на экране, а на переднем плане&nbsp;— сертификат." data-reactid="311">
                    </div>
                </div>
                <title>
                    Placeholder
                </title>
            </div>
        </div>
        <hr class="featurette-divider" style=" height:2px; border-width:0; color:gray; background-color: gray; text-align: center; ">
    </div>

    <div class="container" style="padding-top: 5em! important;">
        <div class="row justify-content-center">
            <h1>May 2020</h1>
            <table class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th scope="col">Week</th>
                    <th scope="col">Monday</th>
                    <th scope="col">Tuesday</th>
                    <th scope="col">Wednesday</th>
                    <th scope="col">Thursday</th>
                    <th scope="col">Friday</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <th scope="row" id="myDIV0">18</th>
                    <td>27</td>
                    <td>28</td>
                    <td>29</td>
                    <td>30</td>
                    <td><a onclick="myFunction0()">1</a>
                        <div id="myDIV0">
                            A brief tour of the courses
                        </div></td>
                </tr>
                <tr>
                    <th scope="row">19</th>
                    <td><a onclick="myFunction0()">4</a>
                        <div id="myDIV1">
                            8:00-11:00 - CS Master’s<br> 11:00-14:00 - Python<br> 15:00-18:00 Machine learning
                        </div></td>
                    <td><a onclick="myFunction0()">5</a>
                        <div id="myDIV2">
                            Whole day - Python
                        </div></td>
                    <td><a onclick="myFunction0()">6</a>
                        <div id="myDIV3">
                            11:00-17:00 - Machine learning
                        </div></td>
                    <td><a onclick="myFunction0()">7</a>
                        <div id="myDIV4">

                        </div></td>
                    <td><a onclick="myFunction0()">8</a>
                        <div id="myDIV5">
                            14:00-18:00 CS Master’s
                        </div></td>
                </tr>
                <tr>
                    <th scope="row">20</th>
                    <td><a onclick="myFunction0()">11</a>
                        <div id="myDIV6">
                            9:00-13:00 CS Master’s<br>
                            14:00-18:00 Machine learning<br>
                        </div></td>
                    <td><a onclick="myFunction0()">12</a>
                        <div id="myDIV7">
                            10:00 - 14:00 Python<br>
                            11:00 - 17:00 Machine learning<br>
                            14:30 - 19:00 CS Master’s
                        </div></td>
                    <td><a onclick="myFunction0()">13</a>
                        <div id="myDIV8">
                            11:00 - 17:00 Python<br>
                            10:30 - 15:00 CS Master’s
                        </div></td>
                    <td><a onclick="myFunction0()">14</a>
                        <div id="myDIV9">
                            11:00 - 17:00 Machine learning<br>
                            14:30 - 19:00 CS Master’s
                        </div></td>
                    <td><a onclick="myFunction0()">15</a>
                        <div id="myDIV10">
                            10:00 - 14:00 Python<br>
                            11:00 - 17:00 Machine learning
                        </div></td>
                </tr>
                <tr>
                    <th scope="row">21</th>
                    <td><a onclick="myFunction0()">18</a>
                        <div id="myDIV11">
                            10:00 - 15:00 Python<br>
                            9:00 - 17:00 Machine learning<br>
                            11:30 - 16:30 CS Master’s
                        </div></td>
                    <td><a onclick="myFunction0()">19</a>
                        <div id="myDIV12">

                        </div></td>
                    <td><a onclick="myFunction0()">20</a>
                        <div id="myDIV13">
                            10:00 - 14:00 Python<br>
                            14:30 - 19:00 CS Master’s
                        </div></td>
                    <td><a onclick="myFunction0()">21</a>
                        <div id="myDIV14">
                            10:00 - 14:00 Python<br>
                            11:00 - 17:00 Machine learning
                        </div></td>
                    <td><a onclick="myFunction0()">22</a>
                        <div id="myDIV15">
                            10:00 - 14:00 Python<br>
                            11:00 - 17:00 Machine learning<br>
                            14:30 - 19:00 CS Master’s
                        </div></td>
                </tr>
                <tr>
                    <th scope="row">22</th>
                    <td><a onclick="myFunction0()">23</a>
                        <div id="myDIV16">
                            10:00 - 14:00 Python<br>
                            11:00 - 17:00 Machine learning<br>
                            14:30 - 19:00 CS Master’s
                        </div></td>
                    <td><a onclick="myFunction0()">24</a>
                        <div id="myDIV17">
                            10:00 - 14:00 Python<br>
                            11:00 - 17:00 Machine learning<br>
                            14:30 - 19:00 CS Master’s
                        </div></td>
                    <td><a onclick="myFunction0()">25</a>
                        <div id="myDIV18">

                        </div></td>
                    <td><a onclick="myFunction0()">26</a>
                        <div id="myDIV19">
                            10:00 - 14:00 Python<br>
                            11:00 - 17:00 Machine learning<br>
                            14:30 - 19:00 CS Master’s
                        </div></td>
                    <td><a onclick="myFunction0()">27</a>
                        <div id="myDIV20">
                            10:00 - 14:00 Python<br>
                            11:00 - 17:00 Machine learning<br>
                            14:30 - 19:00 CS Master’s
                        </div></td>
                </tr>
                <tr>
                    <th scope="row">23</th>
                    <td>1</td>
                    <td>2</td>
                    <td>3</td>
                    <td>4</td>
                    <td>5</td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
    <script>
        function myFunction0() {
            var x = document.getElementById("myDIV0");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
            var x = document.getElementById("myDIV1");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
            var x = document.getElementById("myDIV2");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
            var x = document.getElementById("myDIV3");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
            var x = document.getElementById("myDIV4");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
            var x = document.getElementById("myDIV5");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
            var x = document.getElementById("myDIV6");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
            var x = document.getElementById("myDIV7");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
            var x = document.getElementById("myDIV8");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
            var x = document.getElementById("myDIV9");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
            var x = document.getElementById("myDIV10");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
            var x = document.getElementById("myDIV11");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
            var x = document.getElementById("myDIV12");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
            var x = document.getElementById("myDIV13");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
            var x = document.getElementById("myDIV14");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
            var x = document.getElementById("myDIV15");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
            var x = document.getElementById("myDIV16");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
            var x = document.getElementById("myDIV17");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
            var x = document.getElementById("myDIV18");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
            var x = document.getElementById("myDIV19");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
            var x = document.getElementById("myDIV20");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
        // function myFunction1() {
        //     var x = document.getElementById("myDIV1");
        //     if (x.style.display === "none") {
        //         x.style.display = "block";
        //     } else {
        //         x.style.display = "none";
        //     }
        // }
        // function myFunction2() {
        //     var x = document.getElementById("myDIV2");
        //     if (x.style.display === "none") {
        //         x.style.display = "block";
        //     } else {
        //         x.style.display = "none";
        //     }
        // }
        // function myFunction3() {
        //     var x = document.getElementById("myDIV3");
        //     if (x.style.display === "none") {
        //         x.style.display = "block";
        //     } else {
        //         x.style.display = "none";
        //     }
        // }
        // function myFunction4() {
        //     var x = document.getElementById("myDIV4");
        //     if (x.style.display === "none") {
        //         x.style.display = "block";
        //     } else {
        //         x.style.display = "none";
        //     }
        // }
        // function myFunction5() {
        //     var x = document.getElementById("myDIV5");
        //     if (x.style.display === "none") {
        //         x.style.display = "block";
        //     } else {
        //         x.style.display = "none";
        //     }
        // }
        // function myFunction6() {
        //     var x = document.getElementById("myDIV6");
        //     if (x.style.display === "none") {
        //         x.style.display = "block";
        //     } else {
        //         x.style.display = "none";
        //     }
        // }
        // function myFunction7() {
        //     var x = document.getElementById("myDIV7");
        //     if (x.style.display === "none") {
        //         x.style.display = "block";
        //     } else {
        //         x.style.display = "none";
        //     }
        // }
        // function myFunction8() {
        //     var x = document.getElementById("myDIV8");
        //     if (x.style.display === "none") {
        //         x.style.display = "block";
        //     } else {
        //         x.style.display = "none";
        //     }
        // }
        // function myFunction9() {
        //     var x = document.getElementById("myDIV9");
        //     if (x.style.display === "none") {
        //         x.style.display = "block";
        //     } else {
        //         x.style.display = "none";
        //     }
        // }
        // function myFunction10() {
        //     var x = document.getElementById("myDIV10");
        //     if (x.style.display === "none") {
        //         x.style.display = "block";
        //     } else {
        //         x.style.display = "none";
        //     }
        // }
        // function myFunction11() {
        //     var x = document.getElementById("myDIV11");
        //     if (x.style.display === "none") {
        //         x.style.display = "block";
        //     } else {
        //         x.style.display = "none";
        //     }
        // }
        // function myFunction12() {
        //     var x = document.getElementById("myDIV12");
        //     if (x.style.display === "none") {
        //         x.style.display = "block";
        //     } else {
        //         x.style.display = "none";
        //     }
        // }
        // function myFunction13() {
        //     var x = document.getElementById("myDIV13");
        //     if (x.style.display === "none") {
        //         x.style.display = "block";
        //     } else {
        //         x.style.display = "none";
        //     }
        // }
        // function myFunction14() {
        //     var x = document.getElementById("myDIV14");
        //     if (x.style.display === "none") {
        //         x.style.display = "block";
        //     } else {
        //         x.style.display = "none";
        //     }
        // }
        // function myFunction15() {
        //     var x = document.getElementById("myDIV15");
        //     if (x.style.display === "none") {
        //         x.style.display = "block";
        //     } else {
        //         x.style.display = "none";
        //     }
        // }
        // function myFunction16() {
        //     var x = document.getElementById("myDIV16");
        //     if (x.style.display === "none") {
        //         x.style.display = "block";
        //     } else {
        //         x.style.display = "none";
        //     }
        // }
        // function myFunction17() {
        //     var x = document.getElementById("myDIV17");
        //     if (x.style.display === "none") {
        //         x.style.display = "block";
        //     } else {
        //         x.style.display = "none";
        //     }
        // }
        // function myFunction18() {
        //     var x = document.getElementById("myDIV18");
        //     if (x.style.display === "none") {
        //         x.style.display = "block";
        //     } else {
        //         x.style.display = "none";
        //     }
        // }
        // function myFunction19() {
        //     var x = document.getElementById("myDIV19");
        //     if (x.style.display === "none") {
        //         x.style.display = "block";
        //     } else {
        //         x.style.display = "none";
        //     }
        // }
        // function myFunction20() {
        //     var x = document.getElementById("myDIV20");
        //     if (x.style.display === "none") {
        //         x.style.display = "block";
        //     } else {
        //         x.style.display = "none";
        //     }
        // }
    </script>
</main>
<footer class="container" >

    <p id="footer">
        <a>Article from site: <a style="color: #f9bf4c; padding-top: 50px" href="https://www.coursera.org/user/51753de1fafe484e14b0be1926dc0019">coursera</a></a>
        <a class="float-right"href="#" style="color:darkgrey">Back to top</a>
    </p>

</footer>

