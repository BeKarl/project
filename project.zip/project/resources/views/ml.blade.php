<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Home') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <link href="/css/ml.css"rel="stylesheet" >
</head>
<body >
<div id="app">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">

        <nav class="navbar navbar-dark bg-light">
            <a class="navbar-brand" href="#" style="color: #303a44">
                <svg class="bi bi-intersect" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg" style="color: darkgrey; padding-bottom: 5px">
                    <path fill-rule="evenodd" d="M12 4v6.5a1.5 1.5 0 01-1.5 1.5H4V5.5A1.5 1.5 0 015.5 4H12z" clip-rule="evenodd"/>
                    <path fill-rule="evenodd" d="M14.5 5h-9a.5.5 0 00-.5.5v9a.5.5 0 00.5.5h9a.5.5 0 00.5-.5v-9a.5.5 0 00-.5-.5zm-9-1A1.5 1.5 0 004 5.5v9A1.5 1.5 0 005.5 16h9a1.5 1.5 0 001.5-1.5v-9A1.5 1.5 0 0014.5 4h-9z" clip-rule="evenodd"/>
                    <path fill-rule="evenodd" d="M10.5 1h-9a.5.5 0 00-.5.5v9a.5.5 0 00.5.5h9a.5.5 0 00.5-.5v-9a.5.5 0 00-.5-.5zm-9-1A1.5 1.5 0 000 1.5v9A1.5 1.5 0 001.5 12h9a1.5 1.5 0 001.5-1.5v-9A1.5 1.5 0 0010.5 0h-9z" clip-rule="evenodd"/>
                </svg>
                A.B.P.
            </a>
        </nav>



        <div class="dropdown">
            <button onclick="myFunction()" class="dropbtn"> <span class="navbar-toggler-icon light" style="background-color: white; color: darkgrey"></span></button>
            <div id="myDropdown" class="dropdown-content">
                <p ><a class="btn btn-secondary" href="{{url('/pyth')}}" role="button"  style="background-color: #3aa0aa; border-color:#3aa0aa; color:#353b44 ; ">View details Python >></a></p>
                <p><a class="btn btn-secondary" href="{{url('/data')}}" role="button"  style="background-color: #3aa0aa; border-color:#3aa0aa; color:#353b44 ; ">View details Data >></a></p>
                <p><a class="btn btn-secondary" href="{{url('/home')}}" role="button"  style="background-color: #3aa0aa; border-color:#3aa0aa; color:#353b44 ; ">View Calendar >></a></p>
            </div>
        </div>


        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="navbar-brand" href="{{ url('/') }}">
                        {{ config('app.Home', 'Home') }}
                    </a>
                </li>


            </ul>

            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto">
                <!-- Authentication Links -->
                @guest
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
                    </li>
                    @if (Route::has('register'))
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                        </li>
                    @endif
                @else
                    {{--                    <li class="nav-item dropdown">--}}
                    <a id="navbarDropdown" class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        {{ Auth::user()->name }} <span class="caret"></span>
                    </a>

                    {{--                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">--}}
                    <a class="dropdown-item" href="{{ route('logout') }}"
                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                        {{ __('Logout') }}
                    </a>

                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                        @csrf
                    </form>
                    {{--                        </div>--}}
                    {{--                    </li>--}}
                @endguest
            </ul>
        </div>
    </nav>

    @yield('content')
    <div class="jumbotron" id="Master">
        <font color="#daf7ff"><div class="container">
                <h1 class="display-3" style="color: #303a44; font-family: Appetite;">Master of Computer and <br>Information Technology</h1>
                <p style="color: #303a44; font-size: 20px; font-weight: bold;">University of Pennsylvania</p>
                <img id="penn" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c7/Penn_Quakers_logo.svg/493px-Penn_Quakers_logo.svg.png">
            </div>
        </font>
    </div>

    <div class="container justify-content-center ">
        <!-- Example row of columns -->
        <div class="row featurette justify-content-center">
            <div class="col-md-7">
                <h2 class="featurette-heading">The only online Ivy League master’s degree in Computer Science designed for students without a Computer Science background.</h2>
                <p class="lead">The online Master of Computer and Information Technology degree (MCIT Online) is an online masters degree in Computer Science tailored for non-Computer Science majors. Offered by the University of Pennsylvania, this new program brings the long-running, established on-campus MCIT degree online. The MCIT Online program empowers students without computer science backgrounds to succeed in computing and technology fields. MCIT Online students come from diverse academic backgrounds ranging from business and history to chemistry and medicine.<br></p>
                <br>

                Computer science might not be in your past, but it will be in your future. Technology has an immense impact on our lives, and is creating fields and positions that didn’t exist five years ago. Equipped with a competitive computer science degree, MCIT Online graduates will be uniquely positioned to fill roles in finance, healthcare, education, and government, as well as in the core software development industry. Exposure to real-world projects throughout the program will prepare students to utilize skills that positively impact society.<br>
            </div>
            <div class="col-md-5">
                <div class="_1hrylyvr">
                    <div class="rc-InfoSideabar rc-Section m-l--24" >
                        <div class="rc-AtAGlance" >
                            <ul>
                                <li class="feature-item p-b--24">
                                    <svg class="bi bi-tag" width="1.5em" height="1.5em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" d="M.5 2A1.5 1.5 0 012 .5h4.586a1.5 1.5 0 011.06.44l7 7a1.5 1.5 0 010 2.12l-4.585 4.586a1.5 1.5 0 01-2.122 0l-7-7A1.5 1.5 0 01.5 6.586V2zM2 1.5a.5.5 0 00-.5.5v4.586a.5.5 0 00.146.353l7 7a.5.5 0 00.708 0l4.585-4.585a.5.5 0 000-.708l-7-7a.5.5 0 00-.353-.146H2z" clip-rule="evenodd"/>
                                        <path fill-rule="evenodd" d="M2.5 4.5a2 2 0 114 0 2 2 0 01-4 0zm2-1a1 1 0 100 2 1 1 0 000-2z" clip-rule="evenodd"/>
                                    </svg>
                                    <div class="feature-description">
                                        <div class="feature-title">
                                            <strong aria-label="$25,000 (tuition) + $1,300 (online services fees)">
                                                $25,000 (tuition) + $1,300 (online services fees)
                                            </strong>
                                        </div>
                                    </div>
                                </li>
                                <li class="feature-item p-b--24">
                                    <div class="feature-visual">
                                        <svg class="bi bi-clock" width="1.5em" height="1.5em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" d="M8 15A7 7 0 108 1a7 7 0 000 14zm8-7A8 8 0 110 8a8 8 0 0116 0z" clip-rule="evenodd"/>
                                            <path fill-rule="evenodd" d="M7.5 3a.5.5 0 01.5.5v5.21l3.248 1.856a.5.5 0 01-.496.868l-3.5-2A.5.5 0 017 9V3.5a.5.5 0 01.5-.5z" clip-rule="evenodd"/>
                                        </svg>
                                    </div>
                                    <div class="feature-description">
                                        <div class="feature-title">
                                            <strong aria-label="16-40 months">
                                                16-40 months
                                            </strong>
                                        </div>
                                    </div>
                                </li>
                                <li class="feature-item p-b--24">
                                    <div class="feature-visual">
                                        <svg class="bi bi-bar-chart" width="1.5em" height="1.5em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" d="M4 11H2v3h2v-3zm5-4H7v7h2V7zm5-5h-2v12h2V2zm-2-1a1 1 0 00-1 1v12a1 1 0 001 1h2a1 1 0 001-1V2a1 1 0 00-1-1h-2zM6 7a1 1 0 011-1h2a1 1 0 011 1v7a1 1 0 01-1 1H7a1 1 0 01-1-1V7zm-5 4a1 1 0 011-1h2a1 1 0 011 1v3a1 1 0 01-1 1H2a1 1 0 01-1-1v-3z" clip-rule="evenodd"/>
                                        </svg>
                                    </div>
                                    <div class="feature-description">
                                        <div class="feature-title">
                                            <strong aria-label="10 courses">
                                                10 courses
                                            </strong>
                                        </div>
                                    </div>
                                </li>
                                <li class="feature-item">
                                    <div class="feature-visual">
                                        <svg class="bi bi-map" width="1.5em" height="1.5em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd" d="M15.817.613A.5.5 0 0116 1v13a.5.5 0 01-.402.49l-5 1a.502.502 0 01-.196 0L5.5 14.51l-4.902.98A.5.5 0 010 15V2a.5.5 0 01.402-.49l5-1a.5.5 0 01.196 0l4.902.98 4.902-.98a.5.5 0 01.415.103zM10 2.41l-4-.8v11.98l4 .8V2.41zm1 11.98l4-.8V1.61l-4 .8v11.98zm-6-.8V1.61l-4 .8v11.98l4-.8z" clip-rule="evenodd"/>
                                        </svg>
                                    </div>
                                    <div class="feature-description">
                                        <div class="feature-title">
                                            <strong aria-label="Completely online">
                                                Completely online
                                            </strong>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                            <div class="rc-DeadlineInfo" >
                                <div class="rc-Markdown styled finalDeadlineInfo">
                                    <p>
                                        Applications for the Fall 2020 cohort are now open.
                                    </p>
                                    <p>
                                        The early application deadline is March 1st.
                                    </p>
                                    <p>
                                        The final application deadline is May 1st.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </div> <!-- /container -->

</div>
<hr>
<footer class="container" >
    <p id="footer">
        <a>Article from site: <a id="linkc" href="https://www.coursera.org/user/51753de1fafe484e14b0be1926dc0019">coursera</a></a>
        <a class="float-right"href="#" style="color:darkgrey">Back to top</a>
    </p>
</footer>
<script>
    /* When the user clicks on the button,
    toggle between hiding and showing the dropdown content */
    function myFunction() {
        document.getElementById("myDropdown").classList.toggle("show");
    }

    // Close the dropdown if the user clicks outside of it
    window.onclick = function(event) {
        if (!event.target.matches('.dropbtn')) {
            var dropdowns = document.getElementsByClassName("dropdown-content");
            var i;
            for (i = 0; i < dropdowns.length; i++) {
                var openDropdown = dropdowns[i];
                if (openDropdown.classList.contains('show')) {
                    openDropdown.classList.remove('show');
                }
            }
        }
    }
</script>
</body>
</html>
